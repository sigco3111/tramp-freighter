// 1. External libraries
import React from 'react';
import ReactDOM from 'react-dom/client';

// 2. Internal modules (game logic, state management)
import { GameCoordinator } from './game/state/game-coordinator';
import { NavigationSystem } from './game/game-navigation';

// 3. Components
import App from './App';
import { GameProvider } from './context/GameContext';
import { NotificationProvider } from './context/NotificationContext';

// 4. Data/constants
import { STAR_DATA } from './game/data/star-data';
import { WORMHOLE_DATA } from './game/data/wormhole-data';
import { initDevMode } from './game/constants';
import { devLog } from './game/utils/dev-logger';

// 5. Styles (CSS imports)
import '../css/base.css';
import '../css/custom-select.css';
import '../css/hud.css';
import '../css/modals.css';
import '../css/starmap-scene.css';
import '../css/system-event-info.css';
import '../css/panel/cargo-manifest.css';
import '../css/panel/combat.css';
import '../css/panel/danger-warning.css';
import '../css/panel/dev-admin.css';
import '../css/panel/dialogue.css';
import '../css/panel/distress-call.css';
import '../css/panel/finance.css';
import '../css/panel/info-broker.css';
import '../css/panel/inspection.css';
import '../css/panel/instructions.css';
import '../css/panel/jump-dialog.css';
import '../css/panel/mechanical-failure.css';
import '../css/panel/negotiation.css';
import '../css/panel/outcome.css';
import '../css/panel/pirate-encounter.css';
import '../css/panel/mission-board.css';
import '../css/panel/refuel.css';
import '../css/panel/repair.css';
import '../css/panel/ship-status.css';
import '../css/panel/system-info.css';
import '../css/panel/system-panel.css';
import '../css/panel/trade.css';
import '../css/panel/upgrades.css';
import '../css/panel/achievements.css';
import '../css/notification.css';

/**
 * Initialize GameCoordinator with either saved game or new game.
 *
 * React Migration Spec: Requirements 32.1, 32.2, 32.3, 32.4, 32.5
 *
 * @returns {GameCoordinator} Initialized game coordinator
 * @throws {Error} If initialization fails
 */
function initializeGame() {
  const navigationSystem = new NavigationSystem(STAR_DATA, WORMHOLE_DATA);

  const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA, navigationSystem);

  // Try to load saved game through the manager's canonical restore path
  const loaded = game.loadGame();

  if (loaded) {
    devLog('Game loaded from save');
  } else {
    game.initNewGame();
    devLog('New game initialized');
  }

  // Flush pending saves when the browser tab closes
  if (typeof window !== 'undefined') {
    window.addEventListener('beforeunload', () => {
      game.flushSave();
    });
  }

  return game;
}

/**
 * Render error UI when initialization fails.
 *
 * React Migration Spec: Requirements 23.5, 32.5, 36.4
 *
 * @param {Error} error - The error that occurred
 */
function renderErrorUI(error) {
  console.error('Failed to initialize game:', error);

  ReactDOM.createRoot(document.getElementById('root')).render(
    <div
      style={{
        padding: '40px',
        fontFamily: 'sans-serif',
        maxWidth: '600px',
        margin: '0 auto',
      }}
    >
      <h1>게임을 불러오지 못했습니다</h1>
      <p>
        \n        게임을 초기화하지 못했습니다. 저장 데이터가 손상되었거나\n        브라우저 호환성 문제일 수 있습니다.\n      
      </p>
      <p style={{ color: '#c00', fontFamily: 'monospace', fontSize: '14px' }}>
        {error.message}
      </p>
      <button
        onClick={() => {
          if (
            confirm(
              '저장된 게임이 삭제되고 새로 시작합니다. 계속할까요?'
            )
          ) {
            localStorage.clear();
            window.location.reload();
          }
        }}
        style={{
          padding: '10px 20px',
          fontSize: '16px',
          cursor: 'pointer',
          marginRight: '10px',
        }}
      >
        \n        저장 삭제 후 다시 시작\n      
      </button>
      <button
        onClick={() => window.location.reload()}
        style={{ padding: '10px 20px', fontSize: '16px', cursor: 'pointer' }}
      >
        \n        다시 시도\n      
      </button>
    </div>
  );
}

/**
 * Initialize the application.
 * Initializes dev mode detection, then GameCoordinator, then renders the app.
 *
 * React Migration Spec: Requirements 45.1, 45.2, 45.3
 */
async function initializeApp() {
  // Initialize dev mode detection BEFORE rendering
  // This ensures DEV_MODE is set before React evaluates the App component
  const isDevMode = await initDevMode();

  // Initialize GameCoordinator
  let game;
  try {
    game = initializeGame();
  } catch (error) {
    renderErrorUI(error);
    throw error; // Re-throw to prevent further execution
  }

  // Render application
  // Pass devMode as a prop to ensure React knows about it
  ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
      <GameProvider game={game}>
        <NotificationProvider>
          <App devMode={isDevMode} />
        </NotificationProvider>
      </GameProvider>
    </React.StrictMode>
  );
}

// Start the application
initializeApp();
