import {
  FACTION_CONFIG,
  EVENT_NAMES,
  DEFAULT_PREFERENCES,
  ENDGAME_CONFIG,
  INTELLIGENCE_CONFIG,
} from '../constants.js';
import { devLog } from '../utils/dev-logger.js';
import { generateEpilogue, generateStats } from '../data/epilogue-data.js';
import { TradingManager } from './managers/trading.js';
import { ShipManager } from './managers/ship.js';
import { NPCManager } from './managers/npc.js';
import { NavigationManager } from './managers/navigation.js';
import { RefuelManager } from './managers/refuel.js';
import { RepairManager } from './managers/repair.js';
import { DialogueManager } from './managers/dialogue.js';
import { EventsManager } from './managers/events.js';
import { InfoBrokerManager } from './managers/info-broker.js';
import { EventSystemManager } from './managers/event-system.js';
import { StateManager } from './managers/state.js';
import { InitializationManager } from './managers/initialization.js';
import { SaveLoadManager } from './managers/save-load.js';
import { DangerManager } from './managers/danger.js';
import { CombatManager } from './managers/combat.js';
import { NegotiationManager } from './managers/negotiation.js';
import { InspectionManager } from './managers/inspection.js';
import { DistressManager } from './managers/distress.js';
import { MechanicalFailureManager } from './managers/mechanical-failure.js';
import { MissionManager } from './managers/mission.js';
import { EventEngineManager } from './managers/event-engine.js';
import { QuestManager } from './managers/quest-manager.js';
import { DebtManager } from './managers/debt.js';
import { AchievementsManager } from './managers/achievements.js';
import { InformationBroker } from '../game-information-broker.js';
import {
  isVersionCompatible,
  validateStateStructure,
  migrateFromV1ToV2,
  migrateFromV2ToV2_1,
  migrateFromV2_1ToV4,
  migrateFromV4ToV4_1,
  migrateFromV4_1ToV5,
  addStateDefaults,
} from './state-validators.js';
import { NARRATIVE_EVENTS } from '../data/narrative-events.js';
import { DANGER_EVENTS } from '../data/danger-events.js';
import { ALL_QUESTS } from '../data/quest-definitions.js';

/**
 * GameCoordinator - Full game state coordination with event-driven reactivity
 *
 * This class is the composition root that owns all domain managers and provides
 * the unified API for game state management. It has the same shape as
 * GameCoordinator (`.state`, `.starData`, `.emit()`, `.markDirty()`, etc.)
 * so that managers receiving `this` continue to work unchanged.
 *
 * DOCUMENTATION: Method documentation is maintained in the individual manager classes
 * to avoid duplication. See the respective manager files for detailed parameter and
 * return value documentation.
 *
 * Responsibilities:
 * - Initialize new game with default values
 * - Maintain single source of truth for game state
 * - Provide unified API through delegation to specialized managers
 * - Emit events on state mutations for UI reactivity
 * - Support multiple subscribers per event type
 */
export class GameCoordinator {
  constructor(starData, wormholeData, navigationSystem = null) {
    this.starData = starData;
    this.wormholeData = wormholeData;
    this.navigationSystem = navigationSystem;

    // Check once during initialization to suppress console noise during test runs
    this.isTestEnvironment =
      typeof process !== 'undefined' && process.env?.NODE_ENV === 'test';

    // Animation system reference (set by StarMapCanvas after scene initialization)
    // Used by useAnimationLock hook to check animation state
    this.animationSystem = null;

    // Initialize with null state (will be set by initNewGame or loadGame)
    this.state = null;

    // Initialize managers
    this.eventSystemManager = new EventSystemManager();
    this.stateManager = new StateManager({
      getPlayerCredits: () => this.state.player.credits,
      setPlayerCredits: (value) => {
        this.state.player.credits = value;
      },
      getPlayerDebt: () => this.state.player.debt,
      setPlayerDebt: (value) => {
        this.state.player.debt = value;
      },
      getShipFuel: () => this.state.ship.fuel,
      setShipFuel: (value) => {
        this.state.ship.fuel = value;
      },
      getShipCargo: () => this.state.ship.cargo,
      setShipCargo: (value) => {
        this.state.ship.cargo = value;
      },
      getShipCargoCapacity: () => this.state.ship.cargoCapacity,
      getPlayer: () => this.state.player,
      getShip: () => this.state.ship,
      getActiveMissions: () => this.state.missions?.active,
      getFullState: () => this.state,
      getFuelCapacity: () => this.shipManager.getFuelCapacity(),
      emit: (...args) => this.emit(...args),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.initializationManager = new InitializationManager({
      assignShipQuirks: (rng) => this.shipManager.assignShipQuirks(rng),
      starData: this.starData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.saveLoadManager = new SaveLoadManager({
      getFullState: () => this.state,
      restoreState: (rawState) => this.restoreState(rawState),
      emit: (...args) => this.emit(...args),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.tradingManager = new TradingManager({
      getOwnState: () => ({
        priceKnowledge: this.state.world.priceKnowledge,
        marketConditions: this.state.world.marketConditions,
        currentSystemPrices: this.state.world.currentSystemPrices,
      }),
      getCredits: () => this.state.player.credits,
      getCurrentSystem: () => this.state.player.currentSystem,
      getShipCargo: () => this.state.ship.cargo,
      getCargoRemaining: () => this.stateManager.getCargoRemaining(),
      getDaysElapsed: () => this.state.player.daysElapsed,
      getStats: () => this.state.stats,
      getDangerZone: (systemId) => this.dangerManager.getDangerZone(systemId),
      getActiveEvents: () => this.state.world.activeEvents,
      updateCredits: (value) => this.stateManager.updateCredits(value),
      updateCargo: (newCargo) => this.stateManager.updateCargo(newCargo),
      applyTradeWithholding: (totalRevenue) =>
        this.debtManager.applyWithholding(totalRevenue),
      checkAchievements: () => this.achievementsManager.checkAchievements(),
      updateStats: (key, delta) => {
        if (this.state.stats) {
          this.state.stats[key] = (this.state.stats[key] || 0) + delta;
        }
      },
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      starData: this.starData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.shipManager = new ShipManager({
      getOwnState: () => this.state.ship,
      getCredits: () => this.state.player.credits,
      getCargoRemaining: () => this.stateManager.getCargoRemaining(),
      updateCredits: (value) => this.stateManager.updateCredits(value),
      updateCargo: (newCargo) => this.stateManager.updateCargo(newCargo),
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.npcManager = new NPCManager({
      getOwnState: () => this.state.npcs,
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCredits: () => this.state.player.credits,
      getShipCargo: () => this.state.ship.cargo,
      getShipQuirks: () => this.state.ship.quirks,
      getCargoRemaining: () => this.stateManager.getCargoRemaining(),
      updateCredits: (value) => this.stateManager.updateCredits(value),
      updateCargo: (newCargo) => this.stateManager.updateCargo(newCargo),
      addToCargoArray: (cargoArray, sourceStack, qty) =>
        this.shipManager.addToCargoArray(cargoArray, sourceStack, qty),
      checkAchievements: () => this.achievementsManager.checkAchievements(),
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.navigationManager = new NavigationManager({
      getOwnState: () => ({
        currentSystem: this.state.player.currentSystem,
        visitedSystems: this.state.world.visitedSystems,
      }),
      setCurrentSystem: (systemId) => {
        this.state.player.currentSystem = systemId;
      },
      setCurrentSystemPrices: (prices) => {
        this.state.world.currentSystemPrices = prices;
      },
      getDaysElapsed: () => this.state.player.daysElapsed,
      getActiveEvents: () => this.state.world.activeEvents,
      getMarketConditions: () => this.state.world.marketConditions,
      getStats: () => this.state.stats,
      getDockedSystems: () => this.state.world.narrativeEvents?.dockedSystems,
      getPriceKnowledge: () => this.state.world.priceKnowledge,
      updatePriceKnowledge: (systemId, prices, lastVisit, source) =>
        this.tradingManager.updatePriceKnowledge(
          systemId,
          prices,
          lastVisit,
          source
        ),
      checkAchievements: () => this.achievementsManager.checkAchievements(),
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      starData: this.starData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.refuelManager = new RefuelManager({
      getShipFuel: () => this.state.ship.fuel,
      getCredits: () => this.state.player.credits,
      getCurrentSystem: () => this.state.player.currentSystem,
      getFuelCapacity: () => this.shipManager.getFuelCapacity(),
      updateCredits: (value) => this.stateManager.updateCredits(value),
      updateFuel: (value) => this.stateManager.updateFuel(value),
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      starData: this.starData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.repairManager = new RepairManager({
      getShipCondition: () => ({
        hull: this.state.ship.hull,
        engine: this.state.ship.engine,
        lifeSupport: this.state.ship.lifeSupport,
      }),
      getCredits: () => this.state.player.credits,
      getDaysElapsed: () => this.state.player.daysElapsed,
      getNPCState: (npcId) => this.npcManager.getNPCState(npcId),
      validateAndGetNPCData: (npcId) =>
        this.npcManager.validateAndGetNPCData(npcId),
      getRepTier: (rep) => this.npcManager.getRepTier(rep),
      updateCredits: (value) => this.stateManager.updateCredits(value),
      updateShipCondition: (hull, engine, lifeSupport) =>
        this.shipManager.updateShipCondition(hull, engine, lifeSupport),
      advanceTime: (newDays) => this.eventsManager.updateTime(newDays),
      markDirty: () => this.markDirty(),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.dialogueManager = new DialogueManager({
      getOwnState: () => this.state.dialogue,
      emit: this.emit.bind(this),
      coordinatorRef: this,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.eventsManager = new EventsManager({
      getOwnState: () => ({
        activeEvents: this.state.world.activeEvents,
        daysElapsed: this.state.player.daysElapsed,
      }),
      setDaysElapsed: (newDays) => {
        this.state.player.daysElapsed = newDays;
      },
      setActiveEvents: (events) => {
        this.state.world.activeEvents = events;
      },
      getPriceKnowledge: () => this.state.world.priceKnowledge,
      getMarketConditions: () => this.state.world.marketConditions,
      incrementPriceKnowledgeStaleness: (days) =>
        this.tradingManager.incrementPriceKnowledgeStaleness(days),
      applyMarketRecovery: (daysPassed) =>
        this.tradingManager.applyMarketRecovery(daysPassed),
      recalculatePricesForKnownSystems: () =>
        this.tradingManager.recalculatePricesForKnownSystems(),
      checkLoanDefaults: () => this.npcManager.checkLoanDefaults(),
      processDebtTick: () => {
        this.debtManager.applyInterest();
        return this.debtManager.checkCheckpoint();
      },
      checkMissionDeadlines: () => this.missionManager.checkMissionDeadlines(),
      cleanupOldIntelligence: () =>
        InformationBroker.cleanupOldIntelligence(
          this.state.world.priceKnowledge
        ),
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      starData: this.starData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.infoBrokerManager = new InfoBrokerManager({
      getPriceKnowledge: () => this.state.world.priceKnowledge,
      getActiveEvents: () => this.state.world.activeEvents,
      getCurrentSystem: () => this.state.player.currentSystem,
      getShipUpgrades: () => this.state.ship.upgrades,
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      starData: this.starData,
      navigationSystem: this.navigationSystem,
      coordinatorRef: this,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.dangerManager = new DangerManager({
      getKarma: () => this.state.player.karma,
      setKarma: (value) => {
        this.state.player.karma = value;
      },
      getPlayerFactions: () => this.state.player.factions,
      getDangerFlags: () => this.state.world.dangerFlags,
      getCurrentSystem: () => this.state.player.currentSystem,
      getShipCargo: () => this.state.ship.cargo,
      getShipUpgrades: () => this.state.ship.upgrades,
      getStats: () => this.state.stats,
      updateCargo: (newCargo) => this.stateManager.updateCargo(newCargo),
      checkAchievements: () => this.achievementsManager.checkAchievements(),
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      starData: this.starData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.combatManager = new CombatManager({
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCurrentSystem: () => this.state.player.currentSystem,
      getShipQuirks: () => this.state.ship.quirks,
      getShipUpgrades: () => this.state.ship.upgrades,
      getKarma: () => this.state.player.karma,
      incrementDangerFlag: (flagName) =>
        this.dangerManager.incrementDangerFlag(flagName),
      emit: this.emit.bind(this),
      markDirty: this.markDirty.bind(this),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.negotiationManager = new NegotiationManager({
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCurrentSystem: () => this.state.player.currentSystem,
      getKarma: () => this.state.player.karma,
      getShipCargo: () => this.state.ship.cargo,
      getCredits: () => this.state.player.credits,
      getActiveMissions: () => this.state.missions?.active,
      getHasPriorIntel: () => this.state.world?.flags?.hasPriorIntel || false,
      incrementDangerFlag: (flagName) =>
        this.dangerManager.incrementDangerFlag(flagName),
      emit: this.emit.bind(this),
      markDirty: this.markDirty.bind(this),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.inspectionManager = new InspectionManager({
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCurrentSystem: () => this.state.player.currentSystem,
      getShipCargo: () => this.state.ship.cargo,
      getShipHiddenCargo: () => this.state.ship.hiddenCargo,
      getDangerZone: (systemId) => this.dangerManager.getDangerZone(systemId),
      countRestrictedGoods: (cargo, zone, systemId) =>
        this.dangerManager.countRestrictedGoods(cargo, zone, systemId),
      incrementDangerFlag: (flagName) =>
        this.dangerManager.incrementDangerFlag(flagName),
      emit: this.emit.bind(this),
      markDirty: this.markDirty.bind(this),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.distressManager = new DistressManager({
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCurrentSystem: () => this.state.player.currentSystem,
      incrementDangerFlag: (flagName) =>
        this.dangerManager.incrementDangerFlag(flagName),
      emit: this.emit.bind(this),
      markDirty: this.markDirty.bind(this),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.mechanicalFailureManager = new MechanicalFailureManager({
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCurrentSystem: () => this.state.player.currentSystem,
      getShipCondition: () => ({
        hull: this.state.ship.hull,
        engine: this.state.ship.engine,
        lifeSupport: this.state.ship.lifeSupport,
      }),
      emit: this.emit.bind(this),
      markDirty: this.markDirty.bind(this),
      isTestEnvironment: this.isTestEnvironment,
    });
    this.missionManager = new MissionManager({
      getOwnState: () => this.state.missions,
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCurrentSystem: () => this.state.player.currentSystem,
      getCredits: () => this.state.player.credits,
      getShipCargo: () => this.state.ship.cargo,
      getCargoRemaining: () => this.stateManager.getCargoRemaining(),
      getStats: () => this.state.stats,
      getVisitedSystems: () => this.state.world.visitedSystems,
      getDangerZone: (systemId) => this.dangerManager.getDangerZone(systemId),
      getFactionRep: (faction) => this.dangerManager.getFactionRep(faction),
      updateCredits: (value) => this.stateManager.updateCredits(value),
      applyTradeWithholding: (totalRevenue) =>
        this.debtManager.applyWithholding(totalRevenue),
      modifyFactionRep: (faction, amount, reason) =>
        this.dangerManager.modifyFactionRep(faction, amount, reason),
      modifyRep: (npcId, amount, reason) =>
        this.npcManager.modifyRep(npcId, amount, reason),
      modifyKarma: (amount, reason) =>
        this.dangerManager.modifyKarma(amount, reason),
      modifyColeRep: (delta) => this.debtManager.modifyColeRep(delta),
      removeCargoForMission: (goodType, qty) =>
        this.shipManager.removeCargoForMission(goodType, qty),
      updateStats: (key, delta) => {
        if (this.state.stats) {
          this.state.stats[key] = (this.state.stats[key] || 0) + delta;
        }
      },
      isTanakaQuestActive: () => this.questManager.isTanakaQuestActive(),
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      starData: this.starData,
      wormholeData: this.wormholeData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.eventEngineManager = new EventEngineManager({
      getOwnState: () => this.state.world.narrativeEvents,
      getGameState: () => this.state,
      getDaysElapsed: () => this.state.player.daysElapsed,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.questManager = new QuestManager({
      getOwnState: () => this.state.quests,
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCurrentSystem: () => this.state.player.currentSystem,
      getCredits: () => this.state.player.credits,
      getShipCargo: () => this.state.ship.cargo,
      getShipHull: () => this.state.ship.hull,
      getShipEngine: () => this.state.ship.engine,
      getShipUpgrades: () => this.state.ship.upgrades,
      getNpcs: () => this.state.npcs,
      getDebt: () => this.state.player.debt,
      getNarrativeFlags: () => this.state.world?.narrativeEvents?.flags,
      updateCredits: (value) => this.stateManager.updateCredits(value),
      modifyRepRaw: (npcId, amount, reason) =>
        this.npcManager.modifyRepRaw(npcId, amount, reason),
      modifyKarma: (amount, reason) =>
        this.dangerManager.modifyKarma(amount, reason),
      removeCargoForMission: (goodType, qty) =>
        this.shipManager.removeCargoForMission(goodType, qty),
      setShipEngine: (value) => {
        this.state.ship.engine = value;
        this.emit(EVENT_NAMES.SHIP_CONDITION_CHANGED, {
          hull: this.state.ship.hull,
          engine: this.state.ship.engine,
          lifeSupport: this.state.ship.lifeSupport,
        });
      },
      addShipUpgrade: (upgrade) => {
        if (!this.state.ship.upgrades.includes(upgrade)) {
          this.state.ship.upgrades.push(upgrade);
          this.emit(EVENT_NAMES.UPGRADES_CHANGED, [
            ...this.state.ship.upgrades,
          ]);
        }
      },
      updateStats: (key, delta) => {
        if (this.state.stats) {
          this.state.stats[key] = (this.state.stats[key] || 0) + delta;
        }
      },
      markDirty: this.markDirty.bind(this),
      emit: this.emit.bind(this),
      subscribe: this.subscribe.bind(this),
      starData: this.starData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.debtManager = new DebtManager({
      getOwnState: () => ({
        debt: this.state.player.debt,
        finance: this.state.player.finance,
      }),
      initFinance: (financeObj) => {
        this.state.player.finance = financeObj;
      },
      getDaysElapsed: () => this.state.player.daysElapsed,
      getCredits: () => this.state.player.credits,
      getShipCargo: () => this.state.ship.cargo,
      getCurrentSystem: () => this.state.player.currentSystem,
      updateDebt: (amount) => this.stateManager.updateDebt(amount),
      updateCredits: (value) => this.stateManager.updateCredits(value),
      modifyRepRaw: (npcId, amount, reason) =>
        this.npcManager.modifyRepRaw(npcId, amount, reason),
      markDirty: () => this.markDirty(),
      emit: (...args) => this.emit(...args),
      setNarrativeFlag: (flag) => this.setNarrativeFlag(flag),
      starData: this.starData,
      isTestEnvironment: this.isTestEnvironment,
    });
    this.achievementsManager = new AchievementsManager({
      getOwnState: () => this.state.achievements,
      getNpcs: () => this.state.npcs,
      getDangerFlags: () => this.state.world?.dangerFlags,
      getKarma: () => this.state.player?.karma,
      getDaysElapsed: () => this.state.player.daysElapsed,
      getStats: () => this.state.stats,
      getVisitedSystems: () => this.state.world?.visitedSystems,
      markDirty: this.markDirty.bind(this),
      emit: this.emit.bind(this),
      isTestEnvironment: this.isTestEnvironment,
    });
  }

  /**
   * Set the animation system reference
   *
   * Called by StarMapCanvas after scene initialization to make the animation
   * system accessible to React components via useAnimationLock hook.
   *
   * React Migration Spec: Requirements 43.2, 43.5
   *
   * @param {JumpAnimationSystem} animationSystem - The animation system instance
   */
  setAnimationSystem(animationSystem) {
    this.animationSystem = animationSystem;
  }

  // ========================================================================
  // SHIP CONFIGURATION
  // ========================================================================

  assignShipQuirks(rng = Math.random) {
    return this.shipManager.assignShipQuirks(rng);
  }

  applyQuirkModifiers(baseValue, attribute, quirks) {
    return this.shipManager.applyQuirkModifiers(baseValue, attribute, quirks);
  }

  getQuirkDefinition(quirkId) {
    return this.shipManager.getQuirkDefinition(quirkId);
  }

  getUpgradeDefinition(upgradeId) {
    return this.shipManager.getUpgradeDefinition(upgradeId);
  }

  addQuirk(quirkId) {
    return this.shipManager.addQuirk(quirkId);
  }

  removeQuirk(quirkId) {
    return this.shipManager.removeQuirk(quirkId);
  }

  addUpgrade(upgradeId) {
    return this.shipManager.addUpgrade(upgradeId);
  }

  removeUpgrade(upgradeId) {
    return this.shipManager.removeUpgrade(upgradeId);
  }

  addToCargoArray(cargoArray, sourceStack, qty) {
    return this.shipManager.addToCargoArray(cargoArray, sourceStack, qty);
  }

  // ========================================================================
  // GAME LIFECYCLE
  // ========================================================================

  /**
   * Initialize a new game with default values
   * Uses InitializationManager for state creation but maintains control over state assignment
   *
   * @returns {Object} Complete initial game state
   */
  initNewGame(gameSeed = Date.now().toString()) {
    const completeState =
      this.initializationManager.createInitialState(gameSeed);

    this.state = completeState;

    this._registerEventEngine();

    devLog('New game initialized:', completeState);

    this._emitAllStateEvents(completeState);

    return completeState;
  }

  /**
   * Restore game state from raw save data
   *
   * Single canonical path for state restoration. Validates, migrates,
   * adds defaults, assigns state, registers event engine, and emits
   * UI events.
   *
   * @param {Object} rawState - Raw state data (e.g., from localStorage parse)
   * @returns {{ success: boolean, state?: Object, reason?: string }}
   */
  restoreState(rawState) {
    if (!rawState) {
      return { success: false, reason: 'No state data provided' };
    }

    if (!isVersionCompatible(rawState.meta?.version)) {
      return {
        success: false,
        reason: `호환되지 않는 저장 버전: ${rawState.meta?.version}`,
      };
    }

    let migratedState = this._applyMigrations(rawState);

    if (!validateStateStructure(migratedState)) {
      return {
        success: false,
        reason: '저장 데이터의 구조 검증에 실패했습니다',
      };
    }

    migratedState = addStateDefaults(migratedState, this.starData);

    this.state = migratedState;

    this._registerEventEngine();

    this._emitAllStateEvents(migratedState);

    // Catch up achievements that already meet thresholds (e.g. saves from
    // before the achievements system, or new achievements added in updates).
    this.achievementsManager.checkAchievements();

    devLog('State restored successfully');

    return { success: true, state: migratedState };
  }

  /**
   * Apply version migration chain to raw state
   * @param {Object} state - State to migrate
   * @returns {Object} Migrated state
   * @private
   */
  _applyMigrations(state) {
    const MIGRATIONS = [
      ['1.0.0', (s) => migrateFromV1ToV2(s, this.starData)],
      ['2.0.0', migrateFromV2ToV2_1],
      ['2.1.0', migrateFromV2_1ToV4],
      ['4.0.0', migrateFromV4ToV4_1],
      ['4.1.0', migrateFromV4_1ToV5],
    ];

    let migrated = state;
    for (const [version, migrateFn] of MIGRATIONS) {
      if (migrated.meta.version === version) {
        migrated = migrateFn(migrated);
      }
    }
    return migrated;
  }

  /**
   * Register narrative events, danger events, and quests with the event engine.
   * Shared by initNewGame() and restoreState().
   * @private
   */
  _registerEventEngine() {
    this.eventEngineManager.clearEvents();
    this.eventEngineManager.registerEvents(NARRATIVE_EVENTS);
    this.eventEngineManager.registerEvents(DANGER_EVENTS);
    ALL_QUESTS.forEach((quest) => this.questManager.registerQuest(quest));
  }

  /**
   * Emit all state events for UI synchronization.
   * Shared by initNewGame() and restoreState().
   * @param {Object} state - Complete game state
   * @private
   */
  _emitAllStateEvents(state) {
    const { player, ship, world } = state;

    this.emit(EVENT_NAMES.CREDITS_CHANGED, player.credits);
    this.emit(EVENT_NAMES.DEBT_CHANGED, player.debt);
    this.emit(EVENT_NAMES.FUEL_CHANGED, ship.fuel);
    this.emit(EVENT_NAMES.CARGO_CHANGED, ship.cargo);
    this.emit(EVENT_NAMES.HIDDEN_CARGO_CHANGED, ship.hiddenCargo);
    this.emit(EVENT_NAMES.LOCATION_CHANGED, player.currentSystem);
    this.emit(EVENT_NAMES.TIME_CHANGED, player.daysElapsed);
    this.emit(EVENT_NAMES.PRICE_KNOWLEDGE_CHANGED, world.priceKnowledge);
    this.emit(EVENT_NAMES.ACTIVE_EVENTS_CHANGED, world.activeEvents);
    this.emit(EVENT_NAMES.SHIP_CONDITION_CHANGED, {
      hull: ship.hull,
      engine: ship.engine,
      lifeSupport: ship.lifeSupport,
    });
    this.emit(EVENT_NAMES.UPGRADES_CHANGED, ship.upgrades);
    this.emit(EVENT_NAMES.CARGO_CAPACITY_CHANGED, ship.cargoCapacity);
    this.emit(
      EVENT_NAMES.FUEL_CAPACITY_CHANGED,
      this.shipManager.getFuelCapacity()
    );
    this.emit(EVENT_NAMES.QUIRKS_CHANGED, ship.quirks);
    this.emit(EVENT_NAMES.KARMA_CHANGED, player.karma || 0);
    this.emit(EVENT_NAMES.FACTION_REP_CHANGED, player.factions || {});
    if (player.finance) {
      this.emit(EVENT_NAMES.FINANCE_CHANGED, player.finance);
    }
    if (state.missions) {
      this.emit(EVENT_NAMES.MISSIONS_CHANGED, { ...state.missions });
    }
    if (state.quests) {
      this.emit(EVENT_NAMES.QUEST_CHANGED, { ...state.quests });
    }
    if (state.achievements) {
      this.emit(EVENT_NAMES.ACHIEVEMENTS_CHANGED, { ...state.achievements });
    }
    if (state.preferences) {
      this.emit(EVENT_NAMES.PREFERENCES_CHANGED, { ...state.preferences });
    }
  }

  // ========================================================================
  // EVENT SYSTEM
  // ========================================================================

  subscribe(eventType, callback) {
    return this.eventSystemManager.subscribe(eventType, callback);
  }

  unsubscribe(eventType, callback) {
    return this.eventSystemManager.unsubscribe(eventType, callback);
  }

  emit(eventType, data) {
    return this.eventSystemManager.emit(eventType, data);
  }

  get subscribers() {
    return this.eventSystemManager.getSubscribers();
  }

  // ========================================================================
  // STATE QUERIES
  // ========================================================================

  getState() {
    return this.stateManager.getState();
  }

  getPlayer() {
    return this.stateManager.getPlayer();
  }

  getShip() {
    return this.stateManager.getShip();
  }

  getCurrentSystem() {
    return this.navigationManager.getCurrentSystem();
  }

  getCargoUsed() {
    return this.stateManager.getCargoUsed();
  }

  getTradeCargoUsed() {
    return this.stateManager.getTradeCargoUsed();
  }

  getCargoRemaining() {
    return this.stateManager.getCargoRemaining();
  }

  getFuelCapacity() {
    return this.shipManager.getFuelCapacity();
  }

  isSystemVisited(systemId) {
    return this.navigationManager.isSystemVisited(systemId);
  }

  getShipCondition() {
    return this.shipManager.getShipCondition();
  }

  checkConditionWarnings() {
    return this.shipManager.checkConditionWarnings();
  }

  getPriceKnowledge() {
    return this.tradingManager.getPriceKnowledge();
  }

  getCurrentSystemPrices() {
    return this.tradingManager.getCurrentSystemPrices();
  }

  getKnownPrices(systemId) {
    return this.tradingManager.getKnownPrices(systemId);
  }

  hasVisitedSystem(systemId) {
    return this.tradingManager.hasVisitedSystem(systemId);
  }

  // ========================================================================
  // STATE MUTATIONS
  // ========================================================================

  updateCredits(newCredits) {
    return this.stateManager.updateCredits(newCredits);
  }

  updateDebt(newDebt) {
    return this.stateManager.updateDebt(newDebt);
  }

  updateFuel(newFuel) {
    return this.stateManager.updateFuel(newFuel);
  }

  updateCargo(newCargo) {
    return this.stateManager.updateCargo(newCargo);
  }

  updateLocation(newSystemId) {
    return this.navigationManager.updateLocation(newSystemId);
  }

  setCredits(amount) {
    return this.stateManager.setCredits(amount);
  }

  setDebt(amount) {
    return this.stateManager.setDebt(amount);
  }

  setFuel(amount) {
    return this.stateManager.setFuel(amount);
  }

  updateTime(newDays) {
    return this.eventsManager.updateTime(newDays);
  }

  updateShipName(newName) {
    this.shipManager.updateShipName(newName);
  }

  updateShipCondition(hull, engine, lifeSupport) {
    this.shipManager.updateShipCondition(hull, engine, lifeSupport);
  }

  updateMarketConditions(systemId, goodType, quantityDelta) {
    return this.tradingManager.updateMarketConditions(
      systemId,
      goodType,
      quantityDelta
    );
  }

  applyMarketRecovery(daysPassed) {
    return this.tradingManager.applyMarketRecovery(daysPassed);
  }

  updatePriceKnowledge(
    systemId,
    prices,
    lastVisit = 0,
    source = INTELLIGENCE_CONFIG.SOURCES.VISITED
  ) {
    return this.tradingManager.updatePriceKnowledge(
      systemId,
      prices,
      lastVisit,
      source
    );
  }

  incrementPriceKnowledgeStaleness(days = 1) {
    return this.tradingManager.incrementPriceKnowledgeStaleness(days);
  }

  recalculatePricesForKnownSystems() {
    return this.tradingManager.recalculatePricesForKnownSystems();
  }

  // ========================================================================
  // ECONOMIC EVENTS SYSTEM
  // ========================================================================

  getActiveEvents() {
    return this.eventsManager.getActiveEvents();
  }

  updateActiveEvents(newEvents) {
    return this.eventsManager.updateActiveEvents(newEvents);
  }

  getActiveEventForSystem(systemId) {
    return this.eventsManager.getActiveEventForSystem(systemId);
  }

  getEventType(eventTypeKey) {
    return this.eventsManager.getEventType(eventTypeKey);
  }

  // ========================================================================
  // INFORMATION BROKER SYSTEM
  // ========================================================================

  getIntelligenceCost(systemId) {
    return this.infoBrokerManager.getIntelligenceCost(systemId);
  }

  purchaseIntelligence(systemId, discount = 0) {
    return this.infoBrokerManager.purchaseIntelligence(systemId, discount);
  }

  generateRumor() {
    return this.infoBrokerManager.generateRumor();
  }

  listAvailableIntelligence() {
    return this.infoBrokerManager.listAvailableIntelligence();
  }

  // ========================================================================
  // NPC REPUTATION SYSTEM
  // ========================================================================

  validateAndGetNPCData(npcId) {
    return this.npcManager.validateAndGetNPCData(npcId);
  }

  getRepTier(rep) {
    return this.npcManager.getRepTier(rep);
  }

  getNPCState(npcId) {
    return this.npcManager.getNPCState(npcId);
  }

  modifyRep(npcId, amount, reason) {
    this.npcManager.modifyRep(npcId, amount, reason);
  }

  modifyRepRaw(npcId, amount, reason) {
    this.npcManager.modifyRepRaw(npcId, amount, reason);
  }

  setNpcRep(npcId, value) {
    this.npcManager.setNpcRep(npcId, value);
  }

  // ========================================================================
  // QUEST MANAGEMENT
  // ========================================================================

  registerQuest(questDef) {
    this.questManager.registerQuest(questDef);
  }

  getQuestState(questId) {
    return this.questManager.getQuestState(questId);
  }

  getQuestDefinition(questId) {
    return this.questManager.getQuestDefinition(questId);
  }

  getQuestStage(questId) {
    return this.questManager.getQuestStage(questId);
  }

  advanceQuest(questId) {
    return this.questManager.advanceQuest(questId);
  }

  claimStageRewards(questId) {
    return this.questManager.claimStageRewards(questId);
  }

  hasClaimedStageRewards(questId) {
    return this.questManager.hasClaimedStageRewards(questId);
  }

  updateQuestData(questId, key, value) {
    this.questManager.updateQuestData(questId, key, value);
  }

  isQuestComplete(questId) {
    return this.questManager.isQuestComplete(questId);
  }

  getActiveQuests() {
    return this.questManager.getActiveQuests();
  }

  canStartQuestStage(questId, stage) {
    return this.questManager.canStartStage(questId, stage);
  }

  getUnmetRequirements(questId, stage) {
    return this.questManager.getUnmetRequirements(questId, stage);
  }

  checkQuestObjectives(questId) {
    return this.questManager.checkObjectivesComplete(questId);
  }

  canContributeSupply() {
    return this.questManager.canContributeSupply();
  }

  contributeSupply() {
    return this.questManager.contributeSupply();
  }

  isTanakaQuestActive() {
    return this.questManager.isTanakaQuestActive();
  }

  getTanakaMissionDisplay() {
    if (!this.isTanakaQuestActive()) return null;
    const questState = this.questManager.getQuestState('tanaka');
    const questDef = this.questManager.getQuestDefinition('tanaka');
    if (!questState || !questDef) return null;

    const stageDef = questDef.stages.find((s) => s.stage === questState.stage);
    const stageName = stageDef ? stageDef.name : '알 수 없음';

    let progress = null;
    if (questState.stage === 1) {
      progress = `${questState.data.jumpsCompleted || 0}/${ENDGAME_CONFIG.STAGE_1_JUMPS}회 점프`;
    } else if (questState.stage === 2) {
      progress = `${questState.data.exoticMaterials || 0}/${ENDGAME_CONFIG.STAGE_2_EXOTIC_NEEDED}개 시료`;
    } else if (questState.stage === 4) {
      if (questState.data.messageDelivered) {
        const tanakaSystem = this.starData?.find(
          (s) => s.id === ENDGAME_CONFIG.TANAKA_SYSTEM
        );
        progress = tanakaSystem
          ? `${tanakaSystem.name}의 타나카에게 돌아가기`
          : null;
      } else {
        const deliverySystem = this.starData?.find(
          (s) => s.id === ENDGAME_CONFIG.STAGE_4_DELIVERY_SYSTEM
        );
        progress = deliverySystem ? `${deliverySystem.name}으로 배달` : null;
      }
    }

    return {
      title: `타나카: ${stageName}`,
      progress,
      stage: questState.stage,
    };
  }

  getEffectiveMissionCount() {
    const regularCount = this.state.missions.active.length;
    const tanakaSlot = this.isTanakaQuestActive() ? 1 : 0;
    return regularCount + tanakaSlot;
  }

  startPavonisRun() {
    this.emit(EVENT_NAMES.PAVONIS_RUN_TRIGGERED, true);
  }

  // ========================================================================
  // COLE DEBT SYSTEM
  // ========================================================================

  getDebtInfo() {
    return this.debtManager.getDebtInfo();
  }

  borrowFromCole(amount) {
    return this.debtManager.borrow(amount);
  }

  makeDebtPayment(amount) {
    return this.debtManager.makePayment(amount);
  }

  calculateTradeWithholding(totalRevenue) {
    return this.debtManager.calculateWithholding(totalRevenue);
  }

  applyTradeWithholding(totalRevenue) {
    return this.debtManager.applyWithholding(totalRevenue);
  }

  getHeatTier() {
    return this.debtManager.getHeatTier();
  }

  modifyColeRep(delta) {
    this.debtManager.modifyColeRep(delta);
  }

  processDebtTick() {
    this.debtManager.applyInterest();
    return this.debtManager.checkCheckpoint();
  }

  // ========================================================================
  // ACHIEVEMENTS SYSTEM
  // ========================================================================

  checkAchievements() {
    this.achievementsManager.checkAchievements();
  }

  getAchievementProgress() {
    return this.achievementsManager.getProgress();
  }

  getStatsSnapshot() {
    const state = this.stateManager.getState();
    const stats = state?.stats ?? {};
    const player = state?.player ?? {};
    const world = state?.world ?? {};
    return {
      jumpsCompleted: stats.jumpsCompleted ?? 0,
      creditsEarned: stats.creditsEarned ?? 0,
      cargoHauled: stats.cargoHauled ?? 0,
      charitableActs: stats.charitableActs ?? 0,
      daysElapsed: Math.round(player.daysElapsed ?? 0),
      visitedCount: (world.visitedSystems ?? []).length,
      dangerFlags: world.dangerFlags ?? {},
    };
  }

  // ========================================================================
  // PREFERENCES
  // ========================================================================

  getPreference(key) {
    return this.state?.preferences?.[key] ?? DEFAULT_PREFERENCES[key];
  }

  setPreference(key, value) {
    if (!this.state.preferences) {
      this.state.preferences = { ...DEFAULT_PREFERENCES };
    }
    this.state.preferences[key] = value;
    this.emit(EVENT_NAMES.PREFERENCES_CHANGED, { ...this.state.preferences });
    this.markDirty();
  }

  // ========================================================================
  // DIALOGUE STATE MANAGEMENT
  // ========================================================================

  setDialogueState(npcId, nodeId) {
    return this.dialogueManager.setDialogueState(npcId, nodeId);
  }

  getDialogueState() {
    return this.dialogueManager.getDialogueState();
  }

  clearDialogueState() {
    return this.dialogueManager.clearDialogueState();
  }

  async startDialogue(npcId, nodeId = 'greeting') {
    return await this.dialogueManager.startDialogue(npcId, nodeId);
  }

  async selectDialogueChoice(npcId, choiceIndex) {
    return await this.dialogueManager.selectDialogueChoice(npcId, choiceIndex);
  }

  // ========================================================================
  // NPC BENEFITS SYSTEM - TIP SYSTEM
  // ========================================================================

  canGetTip(npcId) {
    return this.npcManager.canGetTip(npcId);
  }

  getTip(npcId) {
    return this.npcManager.getTip(npcId);
  }

  // ========================================================================
  // NPC BENEFITS SYSTEM - DISCOUNT SYSTEM
  // ========================================================================

  getServiceDiscount(npcId, serviceType) {
    return this.npcManager.getServiceDiscount(npcId, serviceType);
  }

  // ========================================================================
  // NPC BENEFITS SYSTEM - FAVOR SYSTEM
  // ========================================================================

  canRequestFavor(npcId, favorType) {
    return this.npcManager.canRequestFavor(npcId, favorType);
  }

  requestLoan(npcId) {
    return this.npcManager.requestLoan(npcId);
  }

  repayLoan(npcId) {
    return this.npcManager.repayLoan(npcId);
  }

  checkLoanDefaults() {
    this.npcManager.checkLoanDefaults();
  }

  storeCargo(npcId) {
    return this.npcManager.storeCargo(npcId);
  }

  retrieveCargo(npcId) {
    return this.npcManager.retrieveCargo(npcId);
  }

  // ========================================================================
  // NPC BENEFITS SYSTEM - FREE REPAIR SYSTEM
  // ========================================================================

  canGetFreeRepair(npcId) {
    return this.repairManager.canGetFreeRepair(npcId);
  }

  getFreeRepair(npcId, hullDamagePercent) {
    return this.repairManager.applyFreeRepair(npcId, hullDamagePercent);
  }

  // ========================================================================
  // TRADING OPERATIONS
  // ========================================================================

  buyGood(goodType, quantity, price) {
    return this.tradingManager.buyGood(goodType, quantity, price);
  }

  sellGood(stackIndex, quantity, salePrice) {
    return this.tradingManager.sellGood(stackIndex, quantity, salePrice);
  }

  // ========================================================================
  // REFUEL SYSTEM
  // ========================================================================

  getFuelPrice(systemId) {
    return this.refuelManager.getFuelPrice(systemId);
  }

  validateRefuel(currentFuel, amount, credits, pricePerPercent) {
    return this.refuelManager.validateRefuel(
      currentFuel,
      amount,
      credits,
      pricePerPercent
    );
  }

  refuel(amount, discount = 0) {
    return this.refuelManager.refuel(amount, discount);
  }

  // ========================================================================
  // SHIP REPAIR SYSTEM
  // ========================================================================

  getRepairCost(systemType, amount, currentCondition) {
    return this.repairManager.getRepairCost(
      systemType,
      amount,
      currentCondition
    );
  }

  repairShipSystem(systemType, amount, discount = 0) {
    return this.repairManager.repairShipSystem(systemType, amount, discount);
  }

  applyEmergencyPatch(systemType) {
    return this.repairManager.applyEmergencyPatch(systemType);
  }

  cannibalizeSystem(targetType, donations) {
    return this.repairManager.cannibalizeSystem(targetType, donations);
  }

  // ========================================================================
  // UPGRADE SYSTEM
  // ========================================================================

  validateUpgradePurchase(upgradeId) {
    return this.shipManager.validateUpgradePurchase(upgradeId);
  }

  purchaseUpgrade(upgradeId) {
    return this.shipManager.purchaseUpgrade(upgradeId);
  }

  calculateShipCapabilities() {
    return this.shipManager.calculateShipCapabilities();
  }

  // ========================================================================
  // HIDDEN CARGO SYSTEM
  // ========================================================================

  moveToHiddenCargo(good, qty) {
    return this.shipManager.moveToHiddenCargo(good, qty);
  }

  moveToRegularCargo(good, qty) {
    return this.shipManager.moveToRegularCargo(good, qty);
  }

  getHiddenCargo() {
    return this.shipManager.getHiddenCargo();
  }

  clearHiddenCargo() {
    return this.shipManager.clearHiddenCargo();
  }

  // ========================================================================
  // DOCK/UNDOCK OPERATIONS
  // ========================================================================

  recordVisitedPrices() {
    return this.tradingManager.recordVisitedPrices();
  }

  dock() {
    return this.navigationManager.dock();
  }

  undock() {
    return this.navigationManager.undock();
  }

  // ========================================================================
  // SAVE/LOAD SYSTEM
  // ========================================================================

  saveGame() {
    return this.saveLoadManager.saveGame();
  }

  markDirty() {
    this.saveLoadManager.markDirty();
  }

  flushSave() {
    this.saveLoadManager.flushSave();
  }

  loadGame() {
    return this.saveLoadManager.loadGame();
  }

  hasSavedGame() {
    return this.saveLoadManager.hasSavedGame();
  }

  clearSave() {
    return this.saveLoadManager.clearSave();
  }

  get lastSaveTime() {
    return this.saveLoadManager.getLastSaveTime();
  }

  set lastSaveTime(timestamp) {
    this.saveLoadManager.setLastSaveTime(timestamp);
  }

  // ========================================================================
  // DANGER SYSTEM
  // ========================================================================

  getDangerZone(systemId) {
    return this.dangerManager.getDangerZone(systemId);
  }

  calculatePirateEncounterChance(systemId, gameState = this.state) {
    return this.dangerManager.calculatePirateEncounterChance(
      systemId,
      gameState
    );
  }

  calculateInspectionChance(systemId, gameState = this.state) {
    return this.dangerManager.calculateInspectionChance(systemId, gameState);
  }

  getKarma() {
    return this.dangerManager.getKarma();
  }

  setKarma(value) {
    this.dangerManager.setKarma(value);
  }

  modifyKarma(amount, reason) {
    this.dangerManager.modifyKarma(amount, reason);
  }

  getFactionRep(faction) {
    return this.dangerManager.getFactionRep(faction);
  }

  setFactionRep(faction, value) {
    this.dangerManager.setFactionRep(faction, value);
  }

  modifyFactionRep(faction, amount, reason) {
    this.dangerManager.modifyFactionRep(faction, amount, reason);
  }

  hasIllegalMissionCargo() {
    return this.dangerManager.hasIllegalMissionCargo();
  }

  countRestrictedGoods(cargo, zone, systemId) {
    return this.dangerManager.countRestrictedGoods(cargo, zone, systemId);
  }

  removeRestrictedCargo() {
    return this.dangerManager.removeRestrictedCargo();
  }

  incrementDangerFlag(flagName) {
    return this.dangerManager.incrementDangerFlag(flagName);
  }

  resolveCombatChoice(encounter, choice) {
    return this.combatManager.resolveCombatChoice(encounter, choice);
  }

  resolveNegotiation(encounter, choice) {
    return this.negotiationManager.resolveNegotiation(encounter, choice);
  }

  resolveInspection(choice, _gameState) {
    return this.inspectionManager.resolveInspection(choice);
  }

  checkDistressCall() {
    return this.distressManager.checkDistressCall();
  }

  resolveDistressCall(distressCall, choice) {
    return this.distressManager.resolveDistressCallEncounter(
      distressCall,
      choice
    );
  }

  /**
   * Resolve encounter based on type and choice
   * Routes to appropriate specific resolution method
   *
   * @param {Object} encounterData - Full encounter data from event
   * @param {string} choice - Player's choice
   * @returns {Object} Resolution outcome
   */
  resolveEncounter(encounterData, choice) {
    const { type, encounter } = encounterData;

    switch (type) {
      case 'pirate':
        return this.resolvePirateEncounter(encounter, choice);
      case 'inspection':
        return this.resolveInspection(choice, this.getState());
      case 'mechanical_failure':
        return this.resolveMechanicalFailure(
          encounter.type,
          choice,
          this.getState()
        );
      case 'distress_call':
        return this.resolveDistressCall(encounter, choice);
      default:
        throw new Error(`Unknown encounter type: ${type}`);
    }
  }

  /**
   * Resolve pirate encounter based on choice
   * Maps UI choices to appropriate resolution methods
   *
   * @param {Object} encounter - Pirate encounter data
   * @param {string} choice - Player's choice (fight, flee, negotiate, surrender)
   * @returns {Object} Resolution outcome
   */
  resolvePirateEncounter(encounter, choice) {
    switch (choice) {
      case 'fight':
        // Fighting maps to return_fire combat choice
        return this.resolveCombatChoice(encounter, 'return_fire');
      case 'flee':
        // Fleeing maps to evasive combat choice
        return this.resolveCombatChoice(encounter, 'evasive');
      case 'negotiate':
        // Negotiating maps to counter_proposal negotiation choice
        return this.resolveNegotiation(encounter, 'counter_proposal');
      case 'surrender':
        // Surrendering maps to accept_demand negotiation choice
        return this.resolveNegotiation(encounter, 'accept_demand');
      default:
        throw new Error(`Unknown pirate encounter choice: ${choice}`);
    }
  }

  checkMechanicalFailure(_gameState) {
    return this.mechanicalFailureManager.checkMechanicalFailure();
  }

  resolveMechanicalFailure(failureType, choice, _gameState) {
    return this.mechanicalFailureManager.resolveMechanicalFailure(
      failureType,
      choice
    );
  }

  // ========================================================================
  // MISSION SYSTEM
  // ========================================================================

  acceptMission(mission) {
    return this.missionManager.acceptMission(mission);
  }

  completeMission(missionId) {
    return this.missionManager.completeMission(missionId);
  }

  abandonMission(missionId) {
    return this.missionManager.abandonMission(missionId);
  }

  checkMissionDeadlines() {
    return this.missionManager.checkMissionDeadlines();
  }

  removeCargoForMission(goodType, quantity) {
    return this.shipManager.removeCargoForMission(goodType, quantity);
  }

  refreshMissionBoard() {
    return this.missionManager.refreshMissionBoard();
  }

  getCompletableMissions() {
    return this.missionManager.getCompletableMissions();
  }

  getActiveMissions() {
    return this.missionManager.getActiveMissions();
  }

  failMissionsDueToCargoLoss() {
    return this.missionManager.failMissionsDueToCargoLoss();
  }

  updatePassengerSatisfaction(missionId, event) {
    return this.missionManager.updatePassengerSatisfaction(missionId, event);
  }

  modifyAllPassengerSatisfaction(delta) {
    return this.missionManager.modifyAllPassengerSatisfaction(delta);
  }

  dismissMissionFailureNotice(missionId) {
    return this.missionManager.dismissMissionFailureNotice(missionId);
  }

  // ========================================================================
  // EVENT ENGINE
  // ========================================================================

  registerEvent(event) {
    return this.eventEngineManager.registerEvent(event);
  }

  registerEvents(events) {
    return this.eventEngineManager.registerEvents(events);
  }

  checkEvents(eventType, context, rng) {
    return this.eventEngineManager.checkEvents(eventType, context, rng);
  }

  getEventById(id) {
    return this.eventEngineManager.getEventById(id);
  }

  markEventFired(eventId) {
    return this.eventEngineManager.markFired(eventId);
  }

  setEventCooldown(eventId, cooldownDays) {
    return this.eventEngineManager.setCooldown(eventId, cooldownDays);
  }

  setNarrativeFlag(flagName) {
    return this.eventEngineManager.setFlag(flagName);
  }

  getNarrativeFlags() {
    return this.eventEngineManager.getFlags();
  }

  getDaysElapsed() {
    return this.state?.player?.daysElapsed ?? 0;
  }

  getVisitedSystems() {
    return this.state?.world?.visitedSystems ?? [];
  }

  getFactionReps() {
    const reps = {};
    for (const faction of FACTION_CONFIG.FACTIONS) {
      reps[faction] = this.getFactionRep(faction);
    }
    return reps;
  }

  getDangerFlags() {
    return this.state?.world?.dangerFlags ?? {};
  }

  getEpilogueData() {
    return generateEpilogue(this.state);
  }

  getEpilogueStats() {
    return generateStats(this.state);
  }

  markVictory() {
    if (this.state.meta) {
      this.state.meta.victory = true;
      this.navigationManager.updateLocation(ENDGAME_CONFIG.DELTA_PAVONIS_ID);
      this.markDirty();
    }
  }

  devTeleport(systemId) {
    this.navigationManager.updateLocation(systemId);
  }
}
