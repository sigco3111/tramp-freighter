import { SeededRandom } from './utils/seeded-random.js';
import { SOL_SYSTEM_ID, ALPHA_CENTAURI_SYSTEM_ID } from './constants.js';

/**
 * EconomicEventsSystem - Manages random economic events that affect commodity prices
 *
 * Events are temporary market conditions that create trading opportunities and challenges.
 * Each event type has specific triggers, duration, and price modifiers.
 */
export class EconomicEventsSystem {
  /**
   * Event type definitions with triggers, durations, and modifiers
   */
  static EVENT_TYPES = {
    mining_strike: {
      name: '광산 파업',
      description: '노동자 파업 - 광석과 트리튬 부족',
      duration: [10, 18], // Min/max days
      modifiers: {
        ore: 1.5,
        tritium: 1.3,
      },
      chance: 0.05, // 5% per day per eligible system
      targetSystems: 'mining', // Systems with ore production advantage
    },
    medical_emergency: {
      name: '의료 비상사태',
      description: '확산 사태로 의약품이 시급하다',
      duration: [8, 14],
      modifiers: {
        medicine: 2.0,
      },
      chance: 0.03,
      targetSystems: 'any',
    },
    festival: {
      name: '문화 축제',
      description: '축하 분위기로 전자제품과 곡물 수요가 늘어난다',
      duration: [7, 12],
      modifiers: {
        electronics: 1.75,
        grain: 1.2,
      },
      chance: 0.04,
      targetSystems: 'core', // Sol Sphere systems
    },
  };

  /**
   * Core system IDs (Sol and Alpha Centauri)
   */
  static CORE_SYSTEM_IDS = [SOL_SYSTEM_ID, ALPHA_CENTAURI_SYSTEM_ID];

  /**
   * Spectral classes that indicate mining systems (high ore production)
   */
  static MINING_SPECTRAL_CLASSES = ['M', 'L', 'T'];

  /**
   * Update events for new day - trigger new events and remove expired ones
   *
   * @param {Object} gameState - Current game state
   * @param {Array} starData - Star system data
   * @returns {Array} Updated active events array
   */
  static updateEvents(gameState, starData) {
    if (!gameState || !starData) {
      return [];
    }

    const currentDay = gameState.player.daysElapsed;
    let activeEvents = gameState.world.activeEvents;

    // Remove expired events
    activeEvents = EconomicEventsSystem.removeExpiredEvents(
      activeEvents,
      currentDay
    );

    // Try to trigger new events
    for (const eventTypeKey in EconomicEventsSystem.EVENT_TYPES) {
      const eventType = EconomicEventsSystem.EVENT_TYPES[eventTypeKey];

      // Check each system for potential event trigger
      for (const system of starData) {
        // Skip if system already has an active event
        if (activeEvents.some((event) => event.systemId === system.id)) {
          continue;
        }

        // Check if system is eligible for this event type
        if (!EconomicEventsSystem.isSystemEligible(system, eventType)) {
          continue;
        }

        // Roll for event trigger using seeded random
        const seed = `event_${eventTypeKey}_${system.id}_${currentDay}`;
        const rng = new SeededRandom(seed);
        const roll = rng.next();

        if (roll < eventType.chance) {
          // Event triggered!
          const newEvent = EconomicEventsSystem.createEvent(
            eventTypeKey,
            system.id,
            currentDay
          );
          activeEvents.push(newEvent);

          // Only one event per system, so break after creating one
          break;
        }
      }
    }

    return activeEvents;
  }

  /**
   * Check if system is eligible for event type based on target criteria
   *
   * @param {Object} system - Star system data
   * @param {Object} eventType - Event type definition
   * @returns {boolean} True if eligible
   */
  static isSystemEligible(system, eventType) {
    if (!system || !eventType) {
      return false;
    }

    const targetSystems = eventType.targetSystems;

    if (targetSystems === 'any') {
      return true;
    }

    if (targetSystems === 'core') {
      return EconomicEventsSystem.CORE_SYSTEM_IDS.includes(system.id);
    }

    if (targetSystems === 'mining') {
      const spectralLetter = system.type?.charAt(0).toUpperCase();
      return EconomicEventsSystem.MINING_SPECTRAL_CLASSES.includes(
        spectralLetter
      );
    }

    return false;
  }

  /**
   * Create new event instance with unique ID and randomized duration
   *
   * @param {string} eventTypeKey - Event type identifier
   * @param {number} systemId - Target system ID
   * @param {number} currentDay - Current game day
   * @returns {Object} Event instance
   */
  static createEvent(eventTypeKey, systemId, currentDay) {
    const eventType = EconomicEventsSystem.EVENT_TYPES[eventTypeKey];

    if (!eventType) {
      throw new Error(`Unknown event type: ${eventTypeKey}`);
    }

    // Generate unique event ID
    const id = `${eventTypeKey}_${systemId}_${currentDay}`;

    // Randomize duration within range using seeded random
    const seed = `duration_${id}`;
    const rng = new SeededRandom(seed);
    const [minDuration, maxDuration] = eventType.duration;
    const duration =
      minDuration + Math.floor(rng.next() * (maxDuration - minDuration + 1));

    // Calculate end day
    const endDay = currentDay + duration;

    const modifiers = { ...eventType.modifiers };

    return {
      id,
      type: eventTypeKey,
      systemId,
      startDay: currentDay,
      endDay,
      modifiers,
    };
  }

  /**
   * Remove expired events where currentDay > endDay
   *
   * @param {Array} activeEvents - Current active events
   * @param {number} currentDay - Current game day
   * @returns {Array} Filtered active events
   */
  static removeExpiredEvents(activeEvents, currentDay) {
    if (!Array.isArray(activeEvents)) {
      return [];
    }

    return activeEvents
      .filter((event) => {
        // Remove expired events
        if (event.endDay < currentDay) return false;
        // Remove events whose type no longer exists (e.g. supply_glut from old saves)
        if (!Object.hasOwn(EconomicEventsSystem.EVENT_TYPES, event.type))
          return false;
        return true;
      })
      .map((event) => {
        // Sanitize modifiers to match current EVENT_TYPES definition (old saves
        // may carry stale modifier keys from previous versions)
        const typeDef = EconomicEventsSystem.EVENT_TYPES[event.type];
        const validModifiers = typeDef.modifiers;
        const sanitized = {};
        for (const key of Object.keys(event.modifiers || {})) {
          if (key in validModifiers) {
            sanitized[key] = event.modifiers[key];
          }
        }
        // If all stored modifiers were stale, fall back to canonical modifiers
        // so the event still affects trading instead of becoming a zombie that
        // blocks the system from getting new events
        const modifiers =
          Object.keys(sanitized).length > 0 ? sanitized : { ...validModifiers };
        return { ...event, modifiers };
      });
  }

  /**
   * Get active event for a specific system
   *
   * @param {number} systemId - System identifier
   * @param {Array} activeEvents - Active events list
   * @returns {Object|null} Active event or null
   */
  static getActiveEventForSystem(systemId, activeEvents) {
    if (!Array.isArray(activeEvents)) {
      return null;
    }

    return activeEvents.find((event) => event.systemId === systemId) || null;
  }
}
