/**
 * Cargo utility functions
 *
 * Pure utility functions for cargo-related calculations and formatting.
 * These functions are separated from the CargoManifestPanel component
 * to maintain testability and reusability.
 *
 * Architecture: react-migration
 * Validates: Requirements 15.5
 */

/**
 * Format the age of cargo purchase
 *
 * @param {number} currentDay - Current game day
 * @param {number} purchaseDay - Day when cargo was purchased
 * @returns {string} Formatted age text (e.g., "today", "1 day ago", "5 days ago")
 */
export function formatCargoAge(currentDay, purchaseDay) {
  if (purchaseDay === undefined || currentDay === undefined) {
    return '';
  }

  const daysSincePurchase = currentDay - purchaseDay;

  if (daysSincePurchase === 0) {
    return '오늘';
  } else if (daysSincePurchase === 1) {
    return '1일 전';
  } else {
    return `${daysSincePurchase}일 전`;
  }
}
