import { SHIP_CONFIG, REPAIR_CONFIG } from '../../game/constants.js';

/**
 * Calculate repair cost for a ship system
 *
 * Cost is ₡5 per 1% restored. If system is already at maximum condition, cost is 0.
 *
 * @param {number} amount - Percentage points to restore
 * @param {number} currentCondition - Current condition percentage
 * @returns {number} Cost in credits
 */
export function calculateRepairCost(amount, currentCondition) {
  // If already at max, no cost
  if (currentCondition >= SHIP_CONFIG.CONDITION_BOUNDS.MAX) {
    return 0;
  }

  // Calculate cost at ₡5 per 1%
  return Math.ceil(amount * REPAIR_CONFIG.COST_PER_PERCENT);
}

/**
 * Calculate discounted repair cost for a ship system
 *
 * @param {number} amount - Percentage points to restore
 * @param {number} currentCondition - Current condition percentage
 * @param {number} discountPercentage - Discount as decimal (e.g., 0.15 for 15%)
 * @returns {number} Discounted cost in credits
 */
export function calculateDiscountedRepairCost(
  amount,
  currentCondition,
  discountPercentage
) {
  if (currentCondition >= SHIP_CONFIG.CONDITION_BOUNDS.MAX) {
    return 0;
  }
  const baseCost = amount * REPAIR_CONFIG.COST_PER_PERCENT;
  return Math.ceil(baseCost * (1 - discountPercentage));
}

/**
 * Calculate total cost to repair all ship systems to maximum condition
 *
 * Sums the repair costs for hull, engine, and life support to reach 100%.
 *
 * @param {Object} condition - Ship condition object with hull, engine, lifeSupport
 * @returns {number} Total repair cost in credits
 */
export function calculateRepairAllCost(condition) {
  let totalCost = 0;

  // Hull
  const hullAmount = SHIP_CONFIG.CONDITION_BOUNDS.MAX - condition.hull;
  if (hullAmount > 0) {
    totalCost += calculateRepairCost(hullAmount, condition.hull);
  }

  // Engine
  const engineAmount = SHIP_CONFIG.CONDITION_BOUNDS.MAX - condition.engine;
  if (engineAmount > 0) {
    totalCost += calculateRepairCost(engineAmount, condition.engine);
  }

  // Life Support
  const lifeSupportAmount =
    SHIP_CONFIG.CONDITION_BOUNDS.MAX - condition.lifeSupport;
  if (lifeSupportAmount > 0) {
    totalCost += calculateRepairCost(lifeSupportAmount, condition.lifeSupport);
  }

  return totalCost;
}

/**
 * Calculate discounted total cost to repair all ship systems to maximum condition
 *
 * @param {Object} condition - Ship condition object with hull, engine, lifeSupport
 * @param {number} discountPercentage - Discount as decimal (e.g., 0.15 for 15%)
 * @returns {number} Discounted total repair cost in credits
 */
export function calculateDiscountedRepairAllCost(
  condition,
  discountPercentage
) {
  let rawBaseCost = 0;
  const systems = ['hull', 'engine', 'lifeSupport'];
  for (const sys of systems) {
    const amount = SHIP_CONFIG.CONDITION_BOUNDS.MAX - condition[sys];
    if (amount > 0) {
      rawBaseCost += amount * REPAIR_CONFIG.COST_PER_PERCENT;
    }
  }
  return Math.ceil(rawBaseCost * (1 - discountPercentage));
}

/**
 * Validate a repair transaction
 *
 * @param {string} systemType - One of: 'hull', 'engine', 'lifeSupport'
 * @param {number} amount - Percentage points to restore
 * @param {Object} state - Current game state
 * @returns {Object} { valid: boolean, reason: string }
 */
export function validateRepair(systemType, amount, state) {
  const currentCondition = state.ship[systemType];
  const credits = state.player.credits;
  const cost = calculateRepairCost(amount, currentCondition);

  // Validation order matters for user experience:
  // 1. Check for positive amount (basic input validation)
  // 2. Check if system already at max (no repair needed)
  // 3. Check credits (player can fix by earning money)
  // 4. Check if would exceed max (player can fix by reducing amount)

  if (amount <= 0) {
    return { valid: false, reason: '수리량은 양수여야 합니다' };
  }

  if (currentCondition >= SHIP_CONFIG.CONDITION_BOUNDS.MAX) {
    return { valid: false, reason: '시스템이 이미 최대 상태입니다' };
  }

  if (cost > credits) {
    return { valid: false, reason: '수리할 크레딧이 부족합니다' };
  }

  if (currentCondition + amount > SHIP_CONFIG.CONDITION_BOUNDS.MAX) {
    return { valid: false, reason: '수리하면 최대 상태를 초과합니다' };
  }

  return { valid: true };
}

/**
 * Validate repair all transaction
 *
 * @param {Object} condition - Ship condition object with hull, engine, lifeSupport
 * @param {number} credits - Player's current credits
 * @returns {Object} { valid: boolean, reason: string }
 */
export function validateRepairAll(condition, credits) {
  const totalCost = calculateRepairAllCost(condition);

  // Check if all systems already at max
  const allAtMax =
    condition.hull >= SHIP_CONFIG.CONDITION_BOUNDS.MAX &&
    condition.engine >= SHIP_CONFIG.CONDITION_BOUNDS.MAX &&
    condition.lifeSupport >= SHIP_CONFIG.CONDITION_BOUNDS.MAX;

  if (allAtMax) {
    return {
      valid: false,
      reason: '모든 시스템이 이미 최대 상태입니다',
    };
  }

  if (totalCost === 0) {
    return {
      valid: false,
      reason: '모든 시스템이 이미 최대 상태입니다',
    };
  }

  if (credits < totalCost) {
    return { valid: false, reason: '전체 수리에 필요한 크레딧이 부족합니다' };
  }

  return { valid: true };
}

/**
 * Get display name for a system type
 *
 * @param {string} systemType - One of: 'hull', 'engine', 'lifeSupport'
 * @returns {string} Display name
 */
export function getSystemName(systemType) {
  switch (systemType) {
    case 'hull':
      return '선체';
    case 'engine':
      return '엔진';
    case 'lifeSupport':
      return '생명 유지';
    default:
      return systemType.charAt(0).toUpperCase() + systemType.slice(1);
  }
}

/**
 * Get current condition value for a specific ship system
 *
 * @param {Object} condition - Ship condition object with hull, engine, lifeSupport
 * @param {string} systemType - One of: 'hull', 'engine', 'lifeSupport'
 * @returns {number} Current condition percentage
 */
export function getSystemCondition(condition, systemType) {
  switch (systemType) {
    case 'hull':
      return condition.hull;
    case 'engine':
      return condition.engine;
    case 'lifeSupport':
      return condition.lifeSupport;
    default:
      return 0;
  }
}

/**
 * Check if a system is at or below the critical damage threshold
 *
 * @param {number} condition - Current condition percentage
 * @returns {boolean} True if critically damaged
 */
export function isSystemCritical(condition) {
  return condition <= REPAIR_CONFIG.CRITICAL_SYSTEM_THRESHOLD;
}

/**
 * Calculate total donation required to bring a system from its current
 * condition to EMERGENCY_PATCH_TARGET, accounting for waste multiplier
 *
 * @param {number} currentCondition - Current condition of the target system
 * @returns {number} Total percentage points donors must sacrifice
 */
export function calculateCannibalizeRequired(currentCondition) {
  const needed = REPAIR_CONFIG.EMERGENCY_PATCH_TARGET - currentCondition;
  if (needed <= 0) return 0;
  return Math.ceil(needed * REPAIR_CONFIG.CANNIBALIZE_WASTE_MULTIPLIER);
}

/**
 * Calculate maximum donation a system can give without going below donor floor
 *
 * @param {number} donorCondition - Current condition of donor system
 * @returns {number} Maximum percentage points available to donate
 */
export function calculateMaxDonation(donorCondition) {
  return Math.max(
    0,
    Math.floor(donorCondition - REPAIR_CONFIG.CANNIBALIZE_DONOR_MIN)
  );
}

/**
 * Check if player can afford standard repair to get above critical threshold
 *
 * @param {number} currentCondition - Current system condition
 * @param {number} credits - Player credits
 * @returns {boolean} True if player can afford repair above threshold
 */
export function canAffordRepairAboveThreshold(currentCondition, credits) {
  const needed = REPAIR_CONFIG.EMERGENCY_PATCH_TARGET - currentCondition;
  if (needed <= 0) return true;
  const cost = Math.ceil(needed * REPAIR_CONFIG.COST_PER_PERCENT);
  return credits >= cost;
}
