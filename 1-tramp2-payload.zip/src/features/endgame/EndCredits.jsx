import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useGame } from '../../context/GameContext';
import { CREDITS_SECTIONS, buildCastList } from './credits-data.js';
import { CREDITS_CONFIG } from '../../game/constants.js';
import './endgame.css';

export function EndCredits({ onCreditsComplete }) {
  const game = useGame();
  const [scrollFinished, setScrollFinished] = useState(false);
  const [paused, setPaused] = useState(false);
  const pausedRef = useRef(false);
  const scrollRef = useRef(null);
  const animationRef = useRef(null);

  // Direct access acceptable: read-only mount-time value that never changes during credits
  const shipName = useMemo(() => game.getShip()?.name || '당신의 함선', [game]);
  const cast = useMemo(() => buildCastList(), []);

  const handleSkip = useCallback(() => {
    if (animationRef.current) {
      animationRef.current.cancel();
    }
    setScrollFinished(true);
  }, []);

  const handleTogglePause = useCallback(() => {
    const anim = animationRef.current;
    if (!anim || anim.playState === 'finished') return;
    if (pausedRef.current) {
      anim.play();
      pausedRef.current = false;
      setPaused(false);
    } else {
      anim.pause();
      pausedRef.current = true;
      setPaused(true);
    }
  }, []);

  useEffect(() => {
    if (scrollFinished) return;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') handleSkip();
      // Only handle Space when focus is NOT on an interactive control,
      // so that button activation via Space still works normally.
      const tag = e.target?.tagName?.toLowerCase();
      if (
        e.key === ' ' &&
        tag !== 'button' &&
        tag !== 'input' &&
        tag !== 'select' &&
        tag !== 'textarea'
      ) {
        e.preventDefault();
        handleTogglePause();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleSkip, handleTogglePause, scrollFinished]);

  useEffect(() => {
    const el = scrollRef.current;
    if (!el || scrollFinished) return;

    const contentHeight = el.scrollHeight;
    const viewportHeight = window.innerHeight;
    const totalDistance = contentHeight + viewportHeight;
    const durationMs =
      (totalDistance / CREDITS_CONFIG.SCROLL_SPEED_PX_PER_SEC) * 1000;

    const animation = el.animate(
      [
        { transform: `translateY(${viewportHeight}px)` },
        { transform: `translateY(-${contentHeight}px)` },
      ],
      {
        duration: durationMs,
        easing: 'linear',
        fill: 'forwards',
      }
    );

    animationRef.current = animation;
    animation.onfinish = () => setScrollFinished(true);

    return () => animation.cancel();
  }, [scrollFinished]);

  useEffect(() => {
    if (scrollFinished) {
      onCreditsComplete();
    }
  }, [scrollFinished, onCreditsComplete]);

  const renderSection = (section, idx) => {
    switch (section.type) {
      case 'title':
        return (
          <div key={idx} className="credits-section credits-title">
            {section.lines.map((line, i) => (
              <h1 key={i}>{line}</h1>
            ))}
          </div>
        );
      case 'separator':
        return <div key={idx} className="credits-separator" />;
      case 'heading':
        return (
          <div key={idx} className="credits-section credits-heading">
            {section.lines.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </div>
        );
      case 'role':
        return (
          <div key={idx} className="credits-section credits-role">
            <div className="credits-role-title">{section.lines[0]}</div>
            <div className="credits-role-name">{section.lines[1]}</div>
          </div>
        );
      case 'credit-pair':
        return (
          <div key={idx} className="credits-section credits-cast">
            {section.pairs.map(([label, value]) => (
              <div key={label} className="credits-cast-row">
                <span className="credits-cast-name">{label}</span>
                <span className="credits-cast-dots" />
                <span className="credits-cast-role">{value}</span>
              </div>
            ))}
          </div>
        );
      case 'thankyou':
        return (
          <div key={idx} className="credits-section credits-thankyou">
            {section.lines.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </div>
        );
      case 'quote':
        return (
          <div key={idx} className="credits-section credits-quote">
            {section.lines.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </div>
        );
      default:
        return (
          <div key={idx} className="credits-section credits-body">
            {section.lines.map((line, i) => (
              <div key={i}>{line}</div>
            ))}
          </div>
        );
    }
  };

  const castHeadingIdx = CREDITS_SECTIONS.findIndex(
    (s) => s.type === 'heading' && s.lines[0] === 'CAST'
  );

  const beforeCast = CREDITS_SECTIONS.slice(0, castHeadingIdx + 1);
  const afterCast = CREDITS_SECTIONS.slice(castHeadingIdx + 1);

  return (
    <div id="end-credits">
      <div className="credits-center">
        <div className="credits-scroll" ref={scrollRef}>
          {beforeCast.map(renderSection)}

          <div className="credits-section credits-cast">
            {cast.map((npc) => (
              <div key={npc.id} className="credits-cast-row">
                <span className="credits-cast-name">{npc.name}</span>
                <span className="credits-cast-dots" />
                <span className="credits-cast-role">{npc.role}</span>
              </div>
            ))}
            <div className="credits-cast-ship">
              <div>그리고 특별 출연</div>
              <div className="credits-ship-name">{shipName}</div>
              <div>본인 역</div>
            </div>
          </div>

          {afterCast.map((section, idx) =>
            renderSection(section, idx + castHeadingIdx + 1)
          )}
        </div>
      </div>

      {!scrollFinished && (
        <div className="credits-controls">
          <button
            className="credits-pause-btn"
            onClick={handleTogglePause}
            aria-label={paused ? '크레딧 재생' : '크레딧 일시정지'}
          >
            {paused ? '재생' : '일시정지'}
          </button>
          <button
            className="credits-skip-btn"
            onClick={handleSkip}
            aria-label="크레딧 건너뛰기"
          >
            건너뛰기
          </button>
        </div>
      )}
    </div>
  );
}
