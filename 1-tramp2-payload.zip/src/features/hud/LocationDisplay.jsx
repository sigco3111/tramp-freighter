import { useGameEvent } from '../../hooks/useGameEvent';
import { EVENT_NAMES } from '../../game/constants.js';
import { STAR_DATA } from '../../game/data/star-data';
import { calculateDistanceFromSol } from '../../game/constants';

/**
 * LocationDisplay component displays current system and distance from Sol.
 *
 * Uses the Bridge Pattern to subscribe to GameCoordinator events:
 * - locationChanged: Updates when player location changes
 *
 * React Migration Spec: Requirements 7.1, 7.2, 24.4
 */
export function LocationDisplay() {
  const currentSystemId = useGameEvent(EVENT_NAMES.LOCATION_CHANGED);

  // Get current system data
  const system = STAR_DATA.find((s) => s.id === currentSystemId);

  if (!system) {
    throw new Error(
      `Invalid game state: current system ID ${currentSystemId} not found in star data`
    );
  }

  // Calculate distance from Sol
  const distance = calculateDistanceFromSol(system);

  return (
    <div className="hud-section hud-location">
      <div className="hud-row">
        <span className="hud-label">항성계:</span>
        <span id="hud-system" className="hud-value">
          {system.name}
        </span>
      </div>
      <div className="hud-row">
        <span className="hud-label">태양으로부터 거리:</span>
        <span id="hud-distance" className="hud-value">
          {distance.toFixed(1)} 광년
        </span>
      </div>
    </div>
  );
}
