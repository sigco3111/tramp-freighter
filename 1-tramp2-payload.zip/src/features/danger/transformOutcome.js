import { FAILURE_CONFIG } from '../../game/constants.js';

/**
 * Transform a raw DangerManager outcome into the shape OutcomePanel expects.
 *
 * DangerManager returns: { success, costs, rewards, description }
 * OutcomePanel expects: { success, encounterType, choiceMade, explanation,
 *   modifiers, consequences, karmaChanges, reputationChanges, resourceChanges }
 *
 * @param {Object} rawOutcome - Raw outcome from DangerManager resolution
 * @param {string} encounterType - Encounter type (pirate, inspection, etc.)
 * @param {string} choice - Player's choice string
 * @returns {Object} Transformed outcome for OutcomePanel
 */
export function transformOutcomeForDisplay(rawOutcome, encounterType, choice) {
  const resourceChanges = {};

  // Convert costs to negative resource changes (days kept positive as a delay)
  const costs = rawOutcome.costs || {};
  if (costs.hull) resourceChanges.hull = -costs.hull;
  if (costs.engine) resourceChanges.engine = -costs.engine;
  if (costs.fuel) resourceChanges.fuel = -costs.fuel;
  if (costs.lifeSupport) resourceChanges.lifeSupport = -costs.lifeSupport;
  if (costs.days) resourceChanges.days = costs.days;

  // Cargo loss tracking
  if (costs.cargoLoss === true) {
    resourceChanges.cargo =
      -FAILURE_CONFIG.DAMAGE_AMOUNTS.TOTAL_CARGO_LOSS_PERCENT;
  } else if (costs.cargoPercent) {
    resourceChanges.cargo = -costs.cargoPercent;
  }

  // Credit costs (negative)
  if (costs.credits) {
    resourceChanges.credits = (resourceChanges.credits || 0) - costs.credits;
  }

  // Credit rewards (positive)
  const rewards = rawOutcome.rewards || {};
  if (rewards.credits) {
    resourceChanges.credits = (resourceChanges.credits || 0) + rewards.credits;
  }

  // Extract karma changes
  const karmaChanges = [];
  if (rewards.karma) {
    karmaChanges.push({ amount: rewards.karma, reason: encounterType });
  }

  // Extract faction reputation changes
  const reputationChanges = [];
  if (rewards.factionRep) {
    Object.entries(rewards.factionRep).forEach(([faction, amount]) => {
      reputationChanges.push({ faction, amount, reason: encounterType });
    });
  }

  // Build consequences with additional effects
  const consequences = {};
  const additionalEffects = [];

  if (rawOutcome.escalate) {
    additionalEffects.push(
      '해적이 더 공격적으로 변했습니다 (위협 수준 상승)'
    );
  }

  if (costs.restrictedGoodsConfiscated) {
    additionalEffects.push('제한 품목을 세관이 압수했습니다');
  }

  if (costs.hiddenCargoConfiscated) {
    additionalEffects.push('은닉 화물이 발견되어 압수되었습니다');
  }

  if (additionalEffects.length > 0) {
    consequences.additionalEffects = additionalEffects;
  }

  return {
    success: rawOutcome.success,
    encounterType,
    choiceMade: choice,
    explanation: rawOutcome.description,
    modifiers: [],
    consequences,
    karmaChanges,
    reputationChanges,
    resourceChanges,
  };
}
