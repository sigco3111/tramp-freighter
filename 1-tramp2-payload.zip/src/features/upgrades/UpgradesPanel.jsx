import { useState } from 'react';
import { useGameEvent } from '../../hooks/useGameEvent';
import { useGameAction } from '../../hooks/useGameAction';
import { useStarData } from '../../hooks/useStarData';
import {
  validateUpgradePurchase,
  formatUpgradeEffects,
  getAvailableUpgrades,
  getInstalledUpgrades,
  calculateCreditsAfterPurchase,
} from './upgradesUtils';
import { SHIP_CONFIG, EVENT_NAMES } from '../../game/constants';

/**
 * UpgradesPanel component for purchasing ship upgrades.
 *
 * Displays available and installed upgrades with their effects, costs,
 * and tradeoffs. Provides confirmation dialog for permanent upgrades.
 *
 * React Migration Spec: Requirements 8.4
 *
 * @param {Object} props - Component props
 * @param {Function} props.onClose - Callback to close the panel
 * @returns {JSX.Element} Upgrades panel component
 */
export function UpgradesPanel({ onClose }) {
  const starData = useStarData();
  const credits = useGameEvent(EVENT_NAMES.CREDITS_CHANGED);
  const currentSystemId = useGameEvent(EVENT_NAMES.LOCATION_CHANGED);
  const { purchaseUpgrade } = useGameAction();

  const [pendingUpgradeId, setPendingUpgradeId] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Subscribe to upgrades changes to get current upgrade state
  const installedUpgrades = useGameEvent(EVENT_NAMES.UPGRADES_CHANGED);

  // Calculate available and installed upgrades from events
  const availableUpgradeIds = getAvailableUpgrades({
    ship: { upgrades: installedUpgrades || [] },
  });
  const installedUpgradeIds = getInstalledUpgrades({
    ship: { upgrades: installedUpgrades || [] },
  });

  const handlePurchaseClick = (upgradeId) => {
    setPendingUpgradeId(upgradeId);
    setShowConfirmation(true);
  };

  const handleConfirmPurchase = () => {
    if (!pendingUpgradeId) return;

    const purchaseOutcome = purchaseUpgrade(pendingUpgradeId);

    if (purchaseOutcome.success) {
      setShowConfirmation(false);
      setPendingUpgradeId(null);
    }
  };

  const handleCancelPurchase = () => {
    setShowConfirmation(false);
    setPendingUpgradeId(null);
  };

  const renderUpgradeCard = (upgradeId, isInstalled) => {
    const upgrade = SHIP_CONFIG.UPGRADES[upgradeId];
    if (!upgrade) return null;

    const effectsText = formatUpgradeEffects(upgrade.effects);
    const hasTradeoff = upgrade.tradeoff && upgrade.tradeoff !== 'None';
    const validation = validateUpgradePurchase(upgradeId, {
      player: { credits },
      ship: { upgrades: installedUpgrades || [] },
    });

    return (
      <div key={upgradeId} className="upgrade-card">
        <div className="upgrade-header">
          <div className="upgrade-name-container">
            <span className="upgrade-name">{upgrade.name}</span>
            {hasTradeoff && (
              <span className="upgrade-warning-symbol" aria-hidden="true">
                {' '}
                ⚠
              </span>
            )}
          </div>
          <span className="upgrade-cost">₡{upgrade.cost.toLocaleString()}</span>
        </div>

        <div className="upgrade-description">{upgrade.description}</div>

        <div className="upgrade-effects">
          <div className="upgrade-effects-label">효과:</div>
          <ul className="upgrade-effects-list">
            {effectsText.map((effect, index) => (
              <li key={index}>{effect}</li>
            ))}
          </ul>
        </div>

        {hasTradeoff && (
          <div className="upgrade-tradeoff">
            <div className="upgrade-tradeoff-label">단점:</div>
            <div className="upgrade-tradeoff-text">{upgrade.tradeoff}</div>
          </div>
        )}

        {!isInstalled && (
          <>
            <div className="upgrade-actions">
              <button
                className="upgrade-purchase-btn"
                onClick={() => handlePurchaseClick(upgradeId)}
                disabled={!validation.valid}
              >
                구매
              </button>
            </div>
            {!validation.valid && (
              <div className="validation-message error">
                {validation.reason}
              </div>
            )}
          </>
        )}
      </div>
    );
  };

  const renderConfirmationDialog = () => {
    if (!showConfirmation || !pendingUpgradeId) return null;

    const upgrade = SHIP_CONFIG.UPGRADES[pendingUpgradeId];
    if (!upgrade) return null;

    const effectsText = formatUpgradeEffects(upgrade.effects);
    const hasTradeoff = upgrade.tradeoff && upgrade.tradeoff !== 'None';
    const creditsAfter = calculateCreditsAfterPurchase(
      pendingUpgradeId,
      credits
    );

    return (
      <div className="upgrade-confirmation-overlay">
        <div
          className="upgrade-confirmation-dialog"
          role="dialog"
          aria-modal="true"
          aria-labelledby="upgrade-confirm-title"
        >
          <h3 id="upgrade-confirm-title" className="upgrade-confirmation-title">
            {upgrade.name}
          </h3>

          <div className="upgrade-confirmation-effects">
            {effectsText.map((effect, index) => (
              <div key={index} className="upgrade-effect-item">
                • {effect}
              </div>
            ))}
            {hasTradeoff && (
              <div className="upgrade-effect-item upgrade-tradeoff-item">
                <span aria-hidden="true">⚠ </span>
                {upgrade.tradeoff}
              </div>
            )}
          </div>

          <div className="upgrade-confirmation-cost">
            <div className="cost-breakdown">
              <div className="cost-row">
                <span>보유 크레딧:</span>
                <span className="upgrade-current-credits">
                  ₡{credits.toLocaleString()}
                </span>
              </div>
              <div className="cost-row">
                <span>비용:</span>
                <span className="upgrade-cost-value">
                  -₡{upgrade.cost.toLocaleString()}
                </span>
              </div>
              <div className="cost-row total">
                <span>구매 후:</span>
                <span className="upgrade-credits-after">
                  ₡{creditsAfter.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          <div className="upgrade-confirmation-warning">
            ⚠ 업그레이드는 영구적이며 제거할 수 없습니다
          </div>

          <div className="upgrade-confirmation-actions">
            <button
              className="upgrade-cancel-btn"
              onClick={handleCancelPurchase}
            >
              취소
            </button>
            <button
              className="upgrade-confirm-btn"
              onClick={handleConfirmPurchase}
            >
              구매 확인
            </button>
          </div>
        </div>
      </div>
    );
  };

  // Sort available upgrades by cost (cheapest first)
  const sortedAvailableUpgrades = [...availableUpgradeIds].sort(
    (a, b) => SHIP_CONFIG.UPGRADES[a].cost - SHIP_CONFIG.UPGRADES[b].cost
  );

  const currentSystem = starData.find((s) => s.id === currentSystemId);

  if (!currentSystem) {
    throw new Error(
      `Invalid game state: current system ID ${currentSystemId} not found in star data`
    );
  }

  const currentSystemName = currentSystem.name;

  return (
    <div id="upgrades-panel" className="panel-base visible">
      <button className="close-btn" onClick={onClose} aria-label="닫기">
        ×
      </button>
      <h2>
        함선 업그레이드 -  <span>{currentSystemName}</span>
      </h2>

      <div className="upgrades-content">
        {/* Credits Display */}
        <div className="upgrades-credits">
          크레딧:{' '}
          <span id="upgrades-credits-value">₡{credits.toLocaleString()}</span>
        </div>

        {/* Available Upgrades Section */}
        <div className="upgrades-section">
          <h3>구매 가능한 업그레이드</h3>
          <div id="available-upgrades-list" className="upgrades-list">
            {sortedAvailableUpgrades.length === 0 ? (
              <div className="upgrades-empty">모든 업그레이드 설치됨</div>
            ) : (
              sortedAvailableUpgrades.map((upgradeId) =>
                renderUpgradeCard(upgradeId, false)
              )
            )}
          </div>
        </div>

        {/* Installed Upgrades Section */}
        <div className="upgrades-section">
          <h3>설치된 업그레이드</h3>
          <div id="installed-upgrades-list" className="upgrades-list">
            {installedUpgradeIds.length === 0 ? (
              <div className="upgrades-empty">설치된 업그레이드 없음</div>
            ) : (
              installedUpgradeIds.map((upgradeId) =>
                renderUpgradeCard(upgradeId, true)
              )
            )}
          </div>
        </div>
      </div>

      <div className="upgrades-actions">
        <button className="station-btn secondary" onClick={onClose}>
          정거장으로 돌아가기
        </button>
      </div>

      {renderConfirmationDialog()}
    </div>
  );
}
