import { useMemo, useRef } from 'react';
import { useGameEvent } from '../../hooks/useGameEvent';
import { useGame } from '../../context/GameContext';
import { useGameAction } from '../../hooks/useGameAction';
import { useClickOutside } from '../../hooks/useClickOutside';
import { EVENT_NAMES } from '../../game/constants.js';
import { STAR_DATA } from '../../game/data/star-data';
import { calculateDistanceFromSol } from '../../game/constants';
import { getNPCsAtSystem } from '../../game/game-npcs';
import { Modal } from '../../components/Modal';
import { tierKo } from '../../game/tier-ko.js';

/**
 * Station menu component.
 *
 * Displays station information and action buttons when docked.
 * Provides access to Trade, Refuel, Repairs, Info Broker, Upgrades,
 * Cargo Manifest, and Ship Status actions.
 * Shows NPCs present at the current station in a "PEOPLE" section.
 *
 * React Migration Spec: Requirements 9.3
 * NPC Foundation Spec: Requirements 1.1, 1.2, 1.3, 1.4, 1.5
 *
 * @param {Function} onOpenPanel - Callback to open a specific panel
 * @param {Function} onUndock - Callback to undock from station
 */
export function StationMenu({ onOpenPanel, onUndock }) {
  const ref = useRef(null);
  useClickOutside(ref, onUndock);

  const currentSystemId = useGameEvent(EVENT_NAMES.LOCATION_CHANGED);
  const game = useGame();
  const { getNarrativeFlags, dismissMissionFailureNotice } = useGameAction();
  const missions = useGameEvent(EVENT_NAMES.MISSIONS_CHANGED);
  const pendingNotices = missions?.pendingFailureNotices ?? [];
  const currentNotice = pendingNotices[0] ?? null;

  // Get current system data
  const system = STAR_DATA.find((s) => s.id === currentSystemId);

  if (!system) {
    throw new Error(
      `Invalid game state: current system ID ${currentSystemId} not found in star data`
    );
  }

  // Calculate distance from Sol
  const distance = calculateDistanceFromSol(system);

  // Get NPCs at current system (pass narrative flags to resolve quest-revealed NPCs)
  const npcsAtSystem = getNPCsAtSystem(currentSystemId, getNarrativeFlags());

  // Handle NPC selection to open dialogue
  const handleNPCClick = (npcId) => {
    onOpenPanel('dialogue', npcId);
  };

  // Compute NPC display info using Bridge Pattern
  // This memoized computation updates when location changes (via currentSystemId dependency)
  // and provides the NPC display data without direct GameCoordinator method calls
  const npcDisplayData = useMemo(() => {
    return npcsAtSystem.map((npc) => {
      // Access NPC state through GameCoordinator (this is acceptable in useMemo)
      // since it's computed once per location change, not on every render
      const npcState = game.getNPCState(npc.id);
      const currentRep = npcState.rep;
      const tier = game.getRepTier(currentRep);

      return {
        id: npc.id,
        name: npc.name,
        role: npc.role,
        tierName: tier.name,
      };
    });
  }, [npcsAtSystem, game]);

  return (
    <div id="station-interface" className="visible" ref={ref} data-panel>
      <div className="station-header">
        <h2>{system.name}  정거장</h2>
        <button className="close-btn" onClick={onUndock} aria-label="닫기">
          ×
        </button>
      </div>
      <div className="station-info">
        <div className="info-row">
          <span className="label">항성계:</span>
          <span>{system.name}</span>
        </div>
        <div className="info-row">
          <span className="label">태양으로부터 거리:</span>
          <span>{distance.toFixed(1)}  광년</span>
        </div>
      </div>

      {/* PEOPLE section - only shown when NPCs are present */}
      {npcsAtSystem.length > 0 && (
        <div className="station-people">
          <h3>사람들</h3>
          <div className="npc-list">
            {npcDisplayData.map((npcDisplay) => (
              <button
                key={npcDisplay.id}
                className="npc-btn"
                onClick={() => handleNPCClick(npcDisplay.id)}
              >
                <span className="npc-name">{npcDisplay.name}</span>
                <span className="npc-role">{npcDisplay.role}</span>
                <span
                  className={`npc-tier tier-${npcDisplay.tierName.toLowerCase()}`}
                >
                  {tierKo(npcDisplay.tierName)}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="station-actions">
        <button
          className="station-btn"
          onClick={() => onOpenPanel('mission-board')}
        >
          임무 게시판
        </button>
        <button className="station-btn" onClick={() => onOpenPanel('finance')}>
          금융
        </button>
        <button className="station-btn" onClick={() => onOpenPanel('trade')}>
          거래
        </button>
        <button className="station-btn" onClick={() => onOpenPanel('refuel')}>
          주유
        </button>
        <button className="station-btn" onClick={() => onOpenPanel('repair')}>
          수리
        </button>
        <button
          className="station-btn"
          onClick={() => onOpenPanel('info-broker')}
        >
          정보 중개인
        </button>
        <button className="station-btn" onClick={() => onOpenPanel('upgrades')}>
          업그레이드
        </button>
        <button
          className="station-btn"
          onClick={() => onOpenPanel('cargo-manifest')}
        >
          화물 목록
        </button>
        <button
          className="station-btn"
          onClick={() => onOpenPanel('ship-status')}
        >
          함선 상태
        </button>
      </div>
      <Modal
        isOpen={currentNotice !== null}
        onClose={() => dismissMissionFailureNotice(currentNotice?.id)}
        title="임무 실패"
        showCloseButton={true}
      >
        <p>
          {currentNotice?.title}
          {currentNotice?.destination
            ? ` — ${currentNotice.destination}행 배달을 제시간에 완료하지 못했습니다.`
            : ' — 기한이 지났습니다.'}
        </p>
        <p>이 의뢰인은 다시는 당신과 일하지 않을 것입니다.</p>
      </Modal>
    </div>
  );
}
