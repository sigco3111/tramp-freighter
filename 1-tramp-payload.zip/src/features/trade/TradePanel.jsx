import { useState, useEffect, useMemo, useCallback } from 'react';
import { useGameEvent } from '../../hooks/useGameEvent';
import { useTradeActions } from '../../hooks/useTradeActions';
import { useShipActions } from '../../hooks/useShipActions';
import { useStarData } from '../../hooks/useStarData';
import { useDangerZone } from '../../hooks/useDangerZone';
import {
  COMMODITY_TYPES,
  TRADE_CONFIG,
  SHIP_CONFIG,
  UI_CONFIG,
  EVENT_NAMES,
  RESTRICTED_GOODS_CONFIG,
} from '../../game/constants.js';
import {
  capitalizeFirst,
  formatCargoDisplayName,
} from '../../game/utils/string-utils.js';
import {
  validateBuy,
  calculateMaxBuyQuantity,
  calculateProfit,
  formatCargoAge,
} from './tradeUtils';
import { isGoodRestrictedInZone } from '../danger/inspectionUtils.js';

/**
 * TradePanel - React component for trading goods at stations
 *
 * Displays market goods with current prices and cargo stacks with profit calculations.
 * Handles buy/sell transactions through GameCoordinator.
 *
 * Architecture: react-migration
 * Validates: Requirements 8.1, 26.1, 26.2, 26.3, 26.5
 *
 * @param {Object} props
 * @param {Function} props.onClose - Callback to close the panel
 */
export function TradePanel({ onClose }) {
  const starData = useStarData();

  // Subscribe to relevant game events
  const cargo = useGameEvent(EVENT_NAMES.CARGO_CHANGED);
  const credits = useGameEvent(EVENT_NAMES.CREDITS_CHANGED);
  const currentSystemId = useGameEvent(EVENT_NAMES.LOCATION_CHANGED);
  const currentDay = useGameEvent(EVENT_NAMES.TIME_CHANGED);
  const cargoCapacity = useGameEvent(EVENT_NAMES.CARGO_CAPACITY_CHANGED);
  const upgrades = useGameEvent(EVENT_NAMES.UPGRADES_CHANGED);
  const hiddenCargo = useGameEvent(EVENT_NAMES.HIDDEN_CARGO_CHANGED);
  const missions = useGameEvent(EVENT_NAMES.MISSIONS_CHANGED);

  // Get trade actions from domain hook
  const { buyGood, sellGood, recordVisitedPrices, getCurrentSystemPrices } =
    useTradeActions();

  // Get ship actions for hidden cargo transfers
  const { moveToHiddenCargo, moveToRegularCargo } = useShipActions();

  // Update price knowledge when panel opens (records "Visited" data)
  useEffect(() => {
    recordVisitedPrices();
  }, [recordVisitedPrices]);

  // Get current system
  const system = starData.find((s) => s.id === currentSystemId);

  const dangerZone = useDangerZone(currentSystemId);

  if (!system) {
    throw new Error(
      `Invalid game state: current system ID ${currentSystemId} not found in star data`
    );
  }

  // Use Bridge Pattern events exclusively - no direct state access
  // Use centralized defaults to handle cases where events haven't fired yet
  const safeCargoCapacity =
    cargoCapacity ?? UI_CONFIG.DEFAULT_VALUES.CARGO_CAPACITY;
  const safeUpgrades = upgrades ?? [];
  const safeHiddenCargo = hiddenCargo ?? [];
  const safeCargo = cargo ?? [];

  // Calculate cargo capacity including passenger space
  const tradeCargoUsed = safeCargo.reduce((sum, stack) => sum + stack.qty, 0);

  const passengerSpace = useMemo(() => {
    if (!missions || !missions.active) return 0;
    return missions.active
      .filter((m) => m.type === 'passenger' && m.requirements?.cargoSpace)
      .reduce((sum, m) => sum + m.requirements.cargoSpace, 0);
  }, [missions]);

  const cargoUsed = tradeCargoUsed + passengerSpace;
  const cargoRemaining = safeCargoCapacity - cargoUsed;

  // Check for Smuggler's Panels upgrade
  const hasSmugglersPanel = safeUpgrades.includes('smuggler_panels');
  const hiddenCargoUsed = safeHiddenCargo.reduce(
    (sum, stack) => sum + stack.qty,
    0
  );
  const hiddenCargoCapacity = hasSmugglersPanel
    ? SHIP_CONFIG.UPGRADES.smuggler_panels.effects.hiddenCargoCapacity
    : 0;

  // Local state for hidden cargo section toggle
  const [hiddenCargoCollapsed, setHiddenCargoCollapsed] = useState(false);

  // Track whether the player has seen the RESTRICTED explanation
  // localStorage key is component-local UI preference, not game state —
  // not worth centralizing since it's only used here and not saved/loaded
  const [restrictedExplained, setRestrictedExplained] = useState(
    () => localStorage.getItem('restrictedExplained') === 'true'
  );

  const dismissRestrictedHint = useCallback(() => {
    localStorage.setItem('restrictedExplained', 'true');
    setRestrictedExplained(true);
  }, []);

  // Sale feedback message (e.g., Cole's withholding notice)
  // Persists until the next sale or panel close — no auto-dismiss timer
  const [saleFeedback, setSaleFeedback] = useState(null);

  // Get locked prices for current system (prevents intra-system arbitrage)
  const currentSystemPrices = getCurrentSystemPrices();

  // Create state object for validation functions using Bridge Pattern data
  const state = {
    player: { credits },
    ship: {
      cargo: safeCargo,
      cargoCapacity: safeCargoCapacity,
      upgrades: safeUpgrades,
    },
    missions: missions || { active: [] },
  };

  const handleBuyGood = (goodType, quantity, price) => {
    const purchaseOutcome = buyGood(goodType, quantity, price);

    if (!purchaseOutcome.success) {
      throw new Error(`구매 실패: ${purchaseOutcome.reason}`);
    }
  };

  const handleSellStack = (stackIndex, quantity, salePrice) => {
    const saleOutcome = sellGood(stackIndex, quantity, salePrice);

    if (!saleOutcome.success) {
      throw new Error(`판매 실패: ${saleOutcome.reason}`);
    }

    if (saleOutcome.withheld > 0) {
      setSaleFeedback(
        `매출: ₡${saleOutcome.totalRevenue.toLocaleString()} · 콜의 몫: -₡${saleOutcome.withheld.toLocaleString()} · 수령액: ₡${saleOutcome.playerReceives.toLocaleString()} (부채는 줄어들지 않음)`
      );
    }
  };

  const handleMoveToHidden = (goodType, quantity) => {
    const result = moveToHiddenCargo(goodType, quantity);

    if (!result.success) {
      throw new Error(`이동 실패: ${result.reason}`);
    }
  };

  const handleMoveToRegular = (goodType, quantity) => {
    const result = moveToRegularCargo(goodType, quantity);

    if (!result.success) {
      throw new Error(`이동 실패: ${result.reason}`);
    }
  };

  return (
    <div id="trade-panel" className="visible">
      <button className="close-btn" onClick={onClose} aria-label="닫기">
        ×
      </button>
      <h2>
        거래 -  <span id="trade-system-name">{system.name}</span>
      </h2>

      <div className="trade-content">
        {/* Market Goods Section */}
        <div className="trade-section">
          <h3>시장 상품</h3>
          <div id="market-goods" className="goods-list">
            {(() => {
              let hintShown = false;
              return COMMODITY_TYPES.map((goodType) => {
                const price = currentSystemPrices[goodType];

                const maxQuantity = calculateMaxBuyQuantity(price, state);
                const validation = validateBuy(goodType, 1, price, state);
                const isRestricted = isGoodRestrictedInZone(
                  goodType,
                  dangerZone,
                  currentSystemId
                );
                const showHint =
                  isRestricted && !restrictedExplained && !hintShown;
                if (showHint) hintShown = true;

                return (
                  <div key={goodType} className="good-item">
                    <div className="good-info">
                      <div className="good-name">
                        {capitalizeFirst(goodType)}
                      </div>
                      <div className="good-price">
                        {price}  ₡/단위
                        {isRestricted && (
                          <span className="restricted-badge-wrapper">
                            <span
                              className="restricted-badge"
                              title={RESTRICTED_GOODS_CONFIG.RESTRICTED_TOOLTIP}
                              aria-label={`제한 품목: ${RESTRICTED_GOODS_CONFIG.RESTRICTED_TOOLTIP}`}
                            >
                              제한 품목
                            </span>
                            {showHint && (
                              <span className="restricted-hint">
                                {RESTRICTED_GOODS_CONFIG.RESTRICTED_TOOLTIP}
                                <button
                                  className="restricted-hint-dismiss"
                                  onClick={dismissRestrictedHint}
                                  aria-label="제한 품목 설명 닫기"
                                >
                                  알겠습니다
                                </button>
                              </span>
                            )}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="good-actions">
                      <button
                        className="buy-btn"
                        disabled={credits < price || cargoRemaining < 1}
                        onClick={() => handleBuyGood(goodType, 1, price)}
                      >
                        1개 구매
                      </button>
                      <button
                        className="buy-btn"
                        disabled={
                          credits < price * TRADE_CONFIG.QUICK_BUY_QUANTITY ||
                          cargoRemaining < TRADE_CONFIG.QUICK_BUY_QUANTITY
                        }
                        onClick={() =>
                          handleBuyGood(
                            goodType,
                            TRADE_CONFIG.QUICK_BUY_QUANTITY,
                            price
                          )
                        }
                      >
                        구매  {TRADE_CONFIG.QUICK_BUY_QUANTITY}
                      </button>
                      <button
                        className="buy-btn"
                        disabled={maxQuantity < 1}
                        onClick={() =>
                          handleBuyGood(goodType, maxQuantity, price)
                        }
                      >
                        최대 구매
                      </button>
                    </div>

                    {!validation.valid && (
                      <div className="validation-message error" role="alert">
                        {validation.reason}
                      </div>
                    )}
                  </div>
                );
              });
            })()}
          </div>
        </div>

        {/* Cargo Section */}
        <div className="trade-section">
          <h3>내 화물</h3>
          <div className="cargo-capacity-display">
            <span className="capacity-label">적재량:</span>
            <span id="trade-cargo-used">{cargoUsed}</span> /
            <span id="trade-cargo-capacity">{safeCargoCapacity}</span>
            <span className="capacity-remaining">
              (<span id="trade-cargo-remaining">{cargoRemaining}</span>{' '}
              남음)
            </span>
          </div>
          {saleFeedback && (
            <div className="validation-message warning">{saleFeedback}</div>
          )}
          <div id="cargo-stacks" className="cargo-list">
            {safeCargo.length === 0 ? (
              <div className="cargo-empty">화물 없음</div>
            ) : (
              safeCargo.map((stack, index) => {
                const currentPrice = currentSystemPrices[stack.good];
                const profit = calculateProfit(stack, currentPrice);

                let detailsText = `수량: ${stack.qty} | 구매가: ${stack.buyPrice} ₡/단위`;

                if (
                  stack.buySystem !== undefined &&
                  stack.buyDate !== undefined
                ) {
                  const purchaseSystem = starData.find(
                    (s) => s.id === stack.buySystem
                  );

                  const ageText = formatCargoAge(currentDay, stack.buyDate);
                  const systemName = purchaseSystem
                    ? purchaseSystem.name
                    : '알 수 없는 항성계';
                  detailsText += ` ${systemName}에서 (${ageText})`;
                }

                let profitText = '';
                if (profit.direction === 'positive') {
                  profitText = `판매가: ${currentPrice} ₡/단위 | 이익: +${profit.margin} ₡/단위 (+${profit.percentage}%)`;
                } else if (profit.direction === 'negative') {
                  profitText = `판매가: ${currentPrice} ₡/단위 | 손실: ${profit.margin} ₡/단위 (${profit.percentage}%)`;
                } else {
                  profitText = `판매가: ${currentPrice} ₡/단위 | 본전`;
                }

                return (
                  <div key={index} className="cargo-stack">
                    <div className="stack-info">
                      <div className="stack-name">
                        {formatCargoDisplayName(stack.good)}
                      </div>
                      <div className="stack-details">{detailsText}</div>
                      {!stack.missionId && (
                        <div className={`stack-profit ${profit.direction}`}>
                          {profitText}
                        </div>
                      )}
                    </div>

                    {stack.missionId ? (
                      <div className="stack-actions">
                        <span className="mission-cargo-label">
                          임무 화물
                        </span>
                      </div>
                    ) : (
                      <div className="stack-actions">
                        <button
                          className="sell-btn"
                          disabled={stack.qty < 1}
                          onClick={() =>
                            handleSellStack(index, 1, currentPrice)
                          }
                        >
                          1개 판매
                        </button>
                        <button
                          className="sell-btn"
                          onClick={() =>
                            handleSellStack(index, stack.qty, currentPrice)
                          }
                        >
                          전부 판매 ({stack.qty})
                        </button>
                        {hasSmugglersPanel && (
                          <button
                            className="transfer-btn"
                            onClick={() =>
                              handleMoveToHidden(stack.good, stack.qty)
                            }
                          >
                            은닉 화물로 이동
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Hidden Cargo Section */}
        {hasSmugglersPanel && (
          <div
            id="hidden-cargo-section"
            className="trade-section hidden-cargo-section"
          >
            <div className="hidden-cargo-header">
              <h3>은닉 화물</h3>
              <button
                id="toggle-hidden-cargo-btn"
                className="toggle-hidden-cargo-btn"
                onClick={() => setHiddenCargoCollapsed(!hiddenCargoCollapsed)}
                aria-expanded={!hiddenCargoCollapsed}
                aria-controls="hidden-cargo-content"
              >
                {hiddenCargoCollapsed ? '보이기' : '숨기기'}
              </button>
            </div>
            <div
              id="hidden-cargo-content"
              className={`hidden-cargo-content ${
                hiddenCargoCollapsed ? 'collapsed' : ''
              }`}
            >
              <div className="cargo-capacity-display">
                <span className="capacity-label">은닉 적재량:</span>
                <span id="hidden-cargo-used">{hiddenCargoUsed}</span> /
                <span id="hidden-cargo-capacity">{hiddenCargoCapacity}</span>
                <span className="capacity-units">단위</span>
              </div>
              <div id="hidden-cargo-stacks" className="cargo-list">
                {safeHiddenCargo.length === 0 ? (
                  <div className="cargo-empty">은닉 화물 없음</div>
                ) : (
                  safeHiddenCargo.map((stack, index) => {
                    const currentPrice = currentSystemPrices[stack.good];
                    const profit = calculateProfit(stack, currentPrice);

                    let detailsText = `수량: ${stack.qty} | 구매가: ${stack.buyPrice} ₡/단위`;

                    if (
                      stack.buySystem !== undefined &&
                      stack.buyDate !== undefined
                    ) {
                      const purchaseSystem = starData.find(
                        (s) => s.id === stack.buySystem
                      );
                      if (!purchaseSystem) {
                        throw new Error(
                          `Invalid hidden cargo stack: purchase system ID ${stack.buySystem} not found in star data`
                        );
                      }

                      const ageText = formatCargoAge(currentDay, stack.buyDate);
                      detailsText += ` ${purchaseSystem.name}에서 (${ageText})`;
                    }

                    let profitText = '';
                    if (profit.direction === 'positive') {
                      profitText = `판매가: ${currentPrice} ₡/단위 | 이익: +${profit.margin} ₡/단위 (+${profit.percentage}%)`;
                    } else if (profit.direction === 'negative') {
                      profitText = `판매가: ${currentPrice} ₡/단위 | 손실: ${profit.margin} ₡/단위 (${profit.percentage}%)`;
                    } else {
                      profitText = `판매가: ${currentPrice} ₡/단위 | 본전`;
                    }

                    return (
                      <div key={index} className="cargo-stack">
                        <div className="stack-info">
                          <div className="stack-name">
                            {formatCargoDisplayName(stack.good)}
                          </div>
                          <div className="stack-details">{detailsText}</div>
                          {!stack.missionId && (
                            <div className={`stack-profit ${profit.direction}`}>
                              {profitText}
                            </div>
                          )}
                        </div>

                        <div className="stack-actions">
                          <button
                            className="transfer-btn"
                            onClick={() =>
                              handleMoveToRegular(stack.good, stack.qty)
                            }
                          >
                            일반 화물로 이동
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
