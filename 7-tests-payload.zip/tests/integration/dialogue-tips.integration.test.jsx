/**
 * Integration tests for dialogue tip functionality
 *
 * Tests the integration between DialoguePanel, dialogue system, and tip functionality.
 * Verifies that tip options appear when available, are hidden when unavailable,
 * and display correct tip content from NPCs.
 *
 * Requirements: 2.1, 2.3, 2.4
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { GameProvider } from '../../src/context/GameContext.jsx';
import { DialoguePanel } from '../../src/features/dialogue/DialoguePanel.jsx';
import { GameCoordinator } from '@game/state/game-coordinator.js';
import { ALL_NPCS } from '../../src/game/data/npc-data.js';
import { STAR_DATA } from '../../src/game/data/star-data.js';
import { WORMHOLE_DATA } from '../../src/game/data/wormhole-data.js';

describe('Dialogue Tips Integration', () => {
  let game;
  let mockOnClose;

  beforeEach(() => {
    // Mock localStorage
    vi.stubGlobal('localStorage', {
      getItem: vi.fn(() => null),
      setItem: vi.fn(),
      removeItem: vi.fn(),
      clear: vi.fn(),
    });

    // Mock console methods to suppress test output
    vi.stubGlobal('console', {
      log: vi.fn(),
      error: vi.fn(),
      warn: vi.fn(),
    });

    game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
    game.initNewGame();
    mockOnClose = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('Tip option visibility', () => {
    it('should show tip option when NPC has tips and meets reputation requirement', async () => {
      // Use Whisper who has tips and test at Warm reputation
      const npcId = 'whisper_sirius';
      const npcState = game.getNPCState(npcId);
      npcState.rep = 15; // Warm tier (>= 10)
      npcState.lastTipDay = null; // No cooldown

      render(
        <GameProvider game={game}>
          <DialoguePanel npcId={npcId} onClose={mockOnClose} />
        </GameProvider>
      );

      // Wait for dialogue to initialize
      await waitFor(() => {
        expect(screen.getByText('위스퍼')).toBeInTheDocument();
      });

      // Verify tip option is present
      expect(screen.getByText('거래 요령이 있나요?')).toBeInTheDocument();
    });

    it('should hide tip option when NPC reputation is below Warm tier', async () => {
      // Use Whisper with Neutral reputation
      const npcId = 'whisper_sirius';
      const npcState = game.getNPCState(npcId);
      npcState.rep = 5; // Neutral tier (< 10)
      npcState.lastTipDay = null; // No cooldown

      render(
        <GameProvider game={game}>
          <DialoguePanel npcId={npcId} onClose={mockOnClose} />
        </GameProvider>
      );

      // Wait for dialogue to initialize
      await waitFor(() => {
        expect(screen.getByText('위스퍼')).toBeInTheDocument();
      });

      // Verify tip option is not present
      expect(
        screen.queryByText('거래 요령이 있나요?')
      ).not.toBeInTheDocument();
    });

    it('should hide tip option when NPC is on tip cooldown', async () => {
      // Use Whisper with Warm reputation but recent tip
      const npcId = 'whisper_sirius';
      const npcState = game.getNPCState(npcId);
      npcState.rep = 15; // Warm tier

      // Set current day and recent tip day (within 7 days)
      const currentDay = 100;
      game.getState().player.daysElapsed = currentDay;
      npcState.lastTipDay = currentDay - 3; // 3 days ago (< 7 days)

      render(
        <GameProvider game={game}>
          <DialoguePanel npcId={npcId} onClose={mockOnClose} />
        </GameProvider>
      );

      // Wait for dialogue to initialize
      await waitFor(() => {
        expect(screen.getByText('위스퍼')).toBeInTheDocument();
      });

      // Verify tip option is not present due to cooldown
      expect(
        screen.queryByText('거래 요령이 있나요?')
      ).not.toBeInTheDocument();
    });

    it('should hide tip option when NPC has no tips', async () => {
      // Use Father Okonkwo who has empty tips array
      const npcId = 'okonkwo_ross154';
      const npcState = game.getNPCState(npcId);
      npcState.rep = 15; // Warm tier
      npcState.lastTipDay = null; // No cooldown

      render(
        <GameProvider game={game}>
          <DialoguePanel npcId={npcId} onClose={mockOnClose} />
        </GameProvider>
      );

      // Wait for dialogue to initialize
      await waitFor(() => {
        expect(screen.getByText('오콘쿠오 신부')).toBeInTheDocument();
      });

      // Verify no tip option is present (Father Okonkwo doesn't provide trading tips)
      expect(screen.queryByText(/tips for me/)).not.toBeInTheDocument();
    });
  });

  describe('Tip content display', () => {
    it('should display actual tip content when tip option is selected', async () => {
      // Use Whisper with available tip
      const npcId = 'whisper_sirius';
      const npcState = game.getNPCState(npcId);
      npcState.rep = 15; // Warm tier
      npcState.lastTipDay = null; // No cooldown

      render(
        <GameProvider game={game}>
          <DialoguePanel npcId={npcId} onClose={mockOnClose} />
        </GameProvider>
      );

      // Wait for dialogue to initialize
      await waitFor(() => {
        expect(screen.getByText('위스퍼')).toBeInTheDocument();
      });

      // Click the tip option
      const tipButton = screen.getByText('거래 요령이 있나요?');
      fireEvent.click(tipButton);

      // Wait for tip dialogue to appear
      await waitFor(() => {
        // Should show the tip dialogue text plus actual tip content
        expect(
          screen.getByText(/공유된 지식은 배가된 지식입니다/)
        ).toBeInTheDocument();
      });

      // Verify that actual tip content is displayed (should be one of Whisper's tips)
      const whisperNPC = ALL_NPCS.find((npc) => npc.id === npcId);
      const tipTexts = whisperNPC.tips;

      // Check if any of the tip texts appear in the dialogue
      const hasValidTip = tipTexts.some((tip) =>
        screen.queryByText(
          new RegExp(tip.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
        )
      );
      expect(hasValidTip).toBe(true);
    });

    it('should display different tips from different NPCs', async () => {
      // Test Wei Chen's tips
      const weiChenId = 'chen_barnards';
      const weiChenState = game.getNPCState(weiChenId);
      weiChenState.rep = 15; // Warm tier
      weiChenState.lastTipDay = null; // No cooldown

      const { rerender } = render(
        <GameProvider game={game}>
          <DialoguePanel npcId={weiChenId} onClose={mockOnClose} />
        </GameProvider>
      );

      // Wait for Wei Chen dialogue to initialize
      await waitFor(() => {
        expect(screen.getByText('웨이 첸')).toBeInTheDocument();
      });

      // Click Wei Chen's tip option
      const weiTipButton = screen.getByText('부두 일꾼으로서 알려 줄 요령이 있나요?');
      fireEvent.click(weiTipButton);

      // Wait for tip dialogue and capture tip content
      await waitFor(() => {
        expect(
          screen.getByText(/몇 년 동안 이 부두에서 일하면서/)
        ).toBeInTheDocument();
      });

      // Verify Wei Chen's tip content appears
      const weiChenNPC = ALL_NPCS.find((npc) => npc.id === weiChenId);
      const weiTipTexts = weiChenNPC.tips;
      const hasWeiTip = weiTipTexts.some((tip) =>
        screen.queryByText(
          new RegExp(tip.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
        )
      );
      expect(hasWeiTip).toBe(true);

      // Now test Marcus Cole's tips
      const marcusId = 'cole_sol';
      const marcusState = game.getNPCState(marcusId);
      marcusState.rep = 15; // Warm tier
      marcusState.lastTipDay = null; // No cooldown

      rerender(
        <GameProvider game={game}>
          <DialoguePanel npcId={marcusId} onClose={mockOnClose} />
        </GameProvider>
      );

      // Wait for Marcus Cole dialogue to initialize
      await waitFor(() => {
        expect(screen.getByText('마커스 콜')).toBeInTheDocument();
      });

      // Click Marcus Cole's tip option
      const marcusTipButton = screen.getByText('금융 조언이 있나요?');
      fireEvent.click(marcusTipButton);

      // Wait for tip dialogue
      await waitFor(() => {
        expect(
          screen.getByText(/신용 관리는 극소수의 상인만 익히는 기술이지/)
        ).toBeInTheDocument();
      });

      // Verify Marcus Cole's tip content appears (different from Wei Chen's)
      const marcusNPC = ALL_NPCS.find((npc) => npc.id === marcusId);
      const marcusTipTexts = marcusNPC.tips;
      const hasMarcusTip = marcusTipTexts.some((tip) =>
        screen.queryByText(
          new RegExp(tip.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'))
        )
      );
      expect(hasMarcusTip).toBe(true);
    });

    it('should update tip cooldown after tip is given', async () => {
      // Use Captain Vasquez for this test
      const npcId = 'vasquez_epsilon';
      const npcState = game.getNPCState(npcId);
      npcState.rep = 15; // Warm tier
      npcState.lastTipDay = null; // No cooldown

      // Set current day
      const currentDay = 50;
      game.getState().player.daysElapsed = currentDay;

      render(
        <GameProvider game={game}>
          <DialoguePanel npcId={npcId} onClose={mockOnClose} />
        </GameProvider>
      );

      // Wait for dialogue to initialize
      await waitFor(() => {
        expect(screen.getByText('바스케스 선장')).toBeInTheDocument();
      });

      // Click the tip option
      const tipButton = screen.getByText('거래 요령이 있을까요?');
      fireEvent.click(tipButton);

      // Wait for tip dialogue to appear
      await waitFor(() => {
        expect(
          screen.getByText(/아는 걸 나누는 건 언제나 즐겁네/)
        ).toBeInTheDocument();
      });

      // Verify that lastTipDay was updated
      expect(npcState.lastTipDay).toBe(currentDay);

      // Go back to greeting and verify tip option is no longer available
      const responseButton = screen.getByText(
        '그 정보 정말 도움이 되네요.'
      );
      fireEvent.click(responseButton);

      // Wait for return to greeting
      await waitFor(() => {
        expect(
          screen.getByText(/오, 또 자네군/)
        ).toBeInTheDocument();
      });

      // Verify tip option is no longer available due to cooldown
      expect(
        screen.queryByText('거래 요령이 있나요?')
      ).not.toBeInTheDocument();
    });
  });

  describe('Tip option text variations', () => {
    it('should show NPC-specific tip option text', async () => {
      // Test different NPCs have different tip option text
      const testCases = [
        { npcId: 'whisper_sirius', expectedText: '거래 요령이 있나요?' },
        {
          npcId: 'chen_barnards',
          expectedText: '부두 일꾼으로서 알려 줄 요령이 있나요?',
        },
        { npcId: 'cole_sol', expectedText: '금융 조언이 있나요?' },
        { npcId: 'vasquez_epsilon', expectedText: '거래 요령이 있을까요?' },
        { npcId: 'kim_tau_ceti', expectedText: '운영상 요령이 있을까요?' },
        {
          npcId: 'rodriguez_procyon',
          expectedText: '정비 요령이 있나요?',
        },
        { npcId: 'osman_luyten', expectedText: '시장 팁이 있나요?' },
        {
          npcId: 'kowalski_alpha_centauri',
          expectedText: '정거장 운영 요령이 있나요?',
        },
        {
          npcId: 'liu_wolf359',
          expectedText: '위험을 감수하는 요령이 있나요?',
        },
      ];

      for (const { npcId, expectedText } of testCases) {
        // Skip Father Okonkwo as he doesn't have tips
        if (npcId === 'okonkwo_ross154') continue;

        const npcState = game.getNPCState(npcId);
        npcState.rep = 15; // Warm tier
        npcState.lastTipDay = null; // No cooldown

        const { rerender } = render(
          <GameProvider game={game}>
            <DialoguePanel npcId={npcId} onClose={mockOnClose} />
          </GameProvider>
        );

        // Wait for dialogue to initialize
        await waitFor(() => {
          const npcData = ALL_NPCS.find((npc) => npc.id === npcId);
          expect(screen.getByText(npcData.name)).toBeInTheDocument();
        });

        // Verify the specific tip option text appears
        expect(screen.getByText(expectedText)).toBeInTheDocument();

        // Clean up for next iteration
        rerender(<div />);
      }
    });
  });
});
