import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  render,
  screen,
  fireEvent,
  cleanup,
  act,
} from '@testing-library/react';
import { StationMenu } from '../../src/features/station/StationMenu.jsx';
import { GameProvider } from '../../src/context/GameContext.jsx';
import { GameCoordinator } from '@game/state/game-coordinator.js';
import { STAR_DATA } from '../../src/game/data/star-data.js';
import { WORMHOLE_DATA } from '../../src/game/data/wormhole-data.js';
import { ALL_NPCS } from '../../src/game/data/npc-data.js';

/**
 * Unit tests for Station Menu NPC Integration
 * Feature: npc-foundation
 *
 * **Validates: Requirements 1.1, 1.2, 1.4, 1.5**
 *
 * Tests that the station menu correctly displays NPCs when present,
 * omits the PEOPLE section when no NPCs are present, and handles
 * NPC selection to open dialogue.
 */
describe('Station Menu NPC Integration', () => {
  let game;

  beforeEach(() => {
    cleanup();
    game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
    game.initNewGame();
  });

  describe('PEOPLE section visibility', () => {
    it('should display PEOPLE section when NPCs are present at current system', () => {
      // Sol (system 0) has Marcus Cole
      const sol = STAR_DATA.find((s) => s.id === 0);
      act(() => {
        game.updateLocation(sol.id);
      });

      render(
        <GameProvider game={game}>
          <StationMenu onOpenPanel={() => {}} onUndock={() => {}} />
        </GameProvider>
      );

      // Should show PEOPLE section
      expect(screen.getByText('사람들')).toBeInTheDocument();
    });

    it('should omit PEOPLE section when no NPCs are present at current system', () => {
      // Find a system without NPCs
      const npcSystemIds = ALL_NPCS.map((npc) => npc.system);
      const systemWithoutNPCs = STAR_DATA.find(
        (s) => !npcSystemIds.includes(s.id) && s.st > 0
      );

      if (systemWithoutNPCs) {
        act(() => {
          game.updateLocation(systemWithoutNPCs.id);
        });

        render(
          <GameProvider game={game}>
            <StationMenu onOpenPanel={() => {}} onUndock={() => {}} />
          </GameProvider>
        );

        // Should NOT show PEOPLE section
        expect(screen.queryByText('사람들')).not.toBeInTheDocument();
      }
    });

    it('should display NPC name, role, and reputation tier', () => {
      // Sol (system 0) has Marcus Cole
      const sol = STAR_DATA.find((s) => s.id === 0);
      act(() => {
        game.updateLocation(sol.id);
      });

      render(
        <GameProvider game={game}>
          <StationMenu onOpenPanel={() => {}} onUndock={() => {}} />
        </GameProvider>
      );

      // Marcus Cole should be displayed with name, role, and tier
      expect(screen.getByText('마커스 콜')).toBeInTheDocument();
      expect(screen.getByText('고리대금업자')).toBeInTheDocument();
      // Marcus Cole starts at -20 rep which is "Cold" tier
      expect(screen.getByText('냉담')).toBeInTheDocument();
    });
  });

  describe('NPC selection and dialogue', () => {
    it('should call onOpenPanel with dialogue and npcId when NPC is clicked', () => {
      const onOpenPanel = vi.fn();

      // Sol (system 0) has Marcus Cole
      const sol = STAR_DATA.find((s) => s.id === 0);
      act(() => {
        game.updateLocation(sol.id);
      });

      render(
        <GameProvider game={game}>
          <StationMenu onOpenPanel={onOpenPanel} onUndock={() => {}} />
        </GameProvider>
      );

      // Click on Marcus Cole
      const npcButton = screen.getByText('마커스 콜').closest('button');
      fireEvent.click(npcButton);

      // Should call onOpenPanel with dialogue panel and NPC ID
      expect(onOpenPanel).toHaveBeenCalledWith('dialogue', 'cole_sol');
    });
  });

  describe('NPC display at different systems', () => {
    it("should display Wei Chen at Barnard's Star", () => {
      // Barnard's Star (system 4) has Wei Chen
      const barnards = STAR_DATA.find((s) => s.id === 4);
      act(() => {
        game.updateLocation(barnards.id);
      });

      render(
        <GameProvider game={game}>
          <StationMenu onOpenPanel={() => {}} onUndock={() => {}} />
        </GameProvider>
      );

      expect(screen.getByText('웨이 첸')).toBeInTheDocument();
      expect(screen.getByText('부두 일꾼')).toBeInTheDocument();
      // Wei Chen starts at 0 rep which is "Neutral" tier
      expect(screen.getByText('중립')).toBeInTheDocument();
    });

    it('should display Father Okonkwo at Ross 154', () => {
      // Ross 154 (system 11) has Father Okonkwo
      const ross154 = STAR_DATA.find((s) => s.id === 11);
      act(() => {
        game.updateLocation(ross154.id);
      });

      render(
        <GameProvider game={game}>
          <StationMenu onOpenPanel={() => {}} onUndock={() => {}} />
        </GameProvider>
      );

      expect(screen.getByText('오콘쿠오 신부')).toBeInTheDocument();
      expect(screen.getByText('사제')).toBeInTheDocument();
      // Father Okonkwo starts at 10 rep which is "Warm" tier
      expect(screen.getByText('온화')).toBeInTheDocument();
    });
  });

  describe('Reputation tier updates', () => {
    it('should display updated reputation tier after reputation change', () => {
      // Sol (system 0) has Marcus Cole
      const sol = STAR_DATA.find((s) => s.id === 0);

      // Marcus Cole starts at -20 (Cold) and has trust of 0.1
      // To move from Cold (-49 to -10) to Neutral (-9 to 9), we need to get to at least -9
      // With trust modifier of 0.1, we need to add a large amount
      // -20 + (amount * 0.1) >= -9 means amount >= 110
      // Let's add 150 to be safe: -20 + (150 * 0.1) = -20 + 15 = -5 (Neutral)
      game.modifyRep('cole_sol', 150, 'test');

      act(() => {
        game.updateLocation(sol.id);
      });

      render(
        <GameProvider game={game}>
          <StationMenu onOpenPanel={() => {}} onUndock={() => {}} />
        </GameProvider>
      );

      // Should now show Neutral tier instead of Cold
      expect(screen.getByText('중립')).toBeInTheDocument();
      expect(screen.queryByText('Cold')).not.toBeInTheDocument();
    });
  });
});
