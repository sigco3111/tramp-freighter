/**
 * Unit tests for dialogue engine edge cases
 *
 * Tests specific edge cases and error conditions for the dialogue system.
 * Validates: Requirements 2.5, 5.2, 10.1, 10.5
 */

import { describe, it, expect } from 'vitest';
import { GameCoordinator } from '@game/state/game-coordinator.js';
import { showDialogue, selectChoice } from '../../src/game/game-dialogue.js';
import { STAR_DATA } from '../../src/game/data/star-data.js';
import { WORMHOLE_DATA } from '../../src/game/data/wormhole-data.js';

describe('Dialogue Engine Edge Cases', () => {
  let game;

  beforeEach(() => {
    game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
    game.initNewGame();
  });

  describe('Dialogue ending when choice has no next node', () => {
    it('should return null when selecting a choice with next: null', () => {
      const npcId = 'chen_barnards';

      // Set up NPC state
      const npcState = game.getNPCState(npcId);
      npcState.rep = 0;

      // Show initial dialogue
      const initialDialogue = showDialogue(npcId, 'greeting', game);

      // Find the ending choice (should have next: null)
      const endingChoice = initialDialogue.choices.find(
        (choice) => choice.next === null
      );
      expect(endingChoice).toBeDefined();
      expect(endingChoice.text).toBe('지금은 없어요. 몸 조심하세요.');

      // Select the ending choice
      const result = selectChoice(npcId, endingChoice.index, game);

      // Should return null to end dialogue
      expect(result).toBeNull();
    });

    it('should return null for all NPCs when selecting ending choices', () => {
      const npcIds = ['chen_barnards', 'cole_sol', 'okonkwo_ross154'];

      for (const npcId of npcIds) {
        // Set up NPC state
        const npcState = game.getNPCState(npcId);
        npcState.rep = 0;

        // Show initial dialogue
        const initialDialogue = showDialogue(npcId, 'greeting', game);

        // Find ending choices
        const endingChoices = initialDialogue.choices.filter(
          (choice) => choice.next === null
        );
        expect(endingChoices.length).toBeGreaterThan(0);

        // Test each ending choice
        for (const choice of endingChoices) {
          // Reset dialogue state
          showDialogue(npcId, 'greeting', game);

          const result = selectChoice(npcId, choice.index, game);
          expect(result).toBeNull();
        }
      }
    });
  });

  describe('Greeting node is displayed by default', () => {
    it('should show greeting node when no specific node is requested', () => {
      const npcId = 'chen_barnards';

      // Set up NPC state
      const npcState = game.getNPCState(npcId);
      npcState.rep = 0;

      // Show dialogue without specifying node (should default to greeting)
      const dialogue = showDialogue(npcId, undefined, game);

      // Should display greeting content
      expect(dialogue.text).toBe(
        '또 한 명의 상인이네. 도킹 요금은 냈지? 좋아. 뭐가 필요해?'
      );
      expect(dialogue.choices.length).toBeGreaterThan(0);
    });

    it('should show greeting node when explicitly requesting greeting', () => {
      const npcId = 'chen_barnards';

      // Set up NPC state
      const npcState = game.getNPCState(npcId);
      npcState.rep = 0;

      // Show greeting dialogue explicitly
      const dialogue = showDialogue(npcId, 'greeting', game);

      // Should display greeting content
      expect(dialogue.text).toBe(
        '또 한 명의 상인이네. 도킹 요금은 냈지? 좋아. 뭐가 필요해?'
      );
      expect(dialogue.choices.length).toBeGreaterThan(0);
    });

    it('should show greeting for all NPCs by default', () => {
      const npcIds = ['chen_barnards', 'cole_sol', 'okonkwo_ross154'];

      for (const npcId of npcIds) {
        // Set up NPC state
        const npcState = game.getNPCState(npcId);
        npcState.rep = 0;

        // Show dialogue (should default to greeting)
        const dialogue = showDialogue(npcId, undefined, game);

        // Should have valid dialogue content
        expect(typeof dialogue.text).toBe('string');
        expect(dialogue.text.length).toBeGreaterThan(0);
        expect(Array.isArray(dialogue.choices)).toBe(true);
        expect(dialogue.choices.length).toBeGreaterThan(0);
      }
    });
  });

  describe('Uninitialized NPC uses initialRep for dialogue display', () => {
    it('should use Wei Chen initialRep (0) for uninitialized NPC', () => {
      const npcId = 'chen_barnards';

      // Don't initialize NPC state - should use initialRep from NPC data
      // Wei Chen has initialRep: 0, which should show neutral greeting

      const dialogue = showDialogue(npcId, 'greeting', game);

      // Should show neutral greeting (rep 0 is in neutral range)
      expect(dialogue.text).toBe(
        '또 한 명의 상인이네. 도킹 요금은 냈지? 좋아. 뭐가 필요해?'
      );
      expect(dialogue.reputationTier.name).toBe('Neutral');
    });

    it('should use Marcus Cole initialRep (-20) for uninitialized NPC', () => {
      const npcId = 'cole_sol';

      // Don't initialize NPC state - should use initialRep from NPC data
      // Marcus Cole has initialRep: -20, which should show cold greeting

      const dialogue = showDialogue(npcId, 'greeting', game);

      // Should show cold greeting (rep -20 is in cold range)
      expect(dialogue.text).toBe(
        '자네 부채는 여전히 남아 있네. 좋은 소식을 가져왔길 바라네.'
      );
      expect(dialogue.reputationTier.name).toBe('Cold');
    });

    it('should use Father Okonkwo initialRep (10) for uninitialized NPC', () => {
      const npcId = 'okonkwo_ross154';

      // Don't initialize NPC state - should use initialRep from NPC data
      // Father Okonkwo has initialRep: 10, which should show warm greeting

      const dialogue = showDialogue(npcId, 'greeting', game);

      // Should show warm greeting (rep 10 is in warm range)
      expect(dialogue.text).toBe(
        '어서 오세요, 아이여. 무사한 모습을 보니 마음이 놓이는군요. 별 사이의 공허는 외로울 수 있지요. 이곳은 언제나 환영합니다.'
      );
      expect(dialogue.reputationTier.name).toBe('Warm');
    });

    it('should transition from initialRep to actual rep after first interaction', () => {
      const npcId = 'chen_barnards';

      // Show dialogue with uninitialized NPC (should use initialRep: 0)
      const initialDialogue = showDialogue(npcId, 'greeting', game);
      expect(initialDialogue.reputationTier.name).toBe('Neutral');

      // Now the NPC state should be initialized
      const npcState = game.getNPCState(npcId);
      expect(npcState.rep).toBe(0); // Should be initialized to 0

      // Modify reputation
      npcState.rep = 50; // Set to friendly range

      // Show dialogue again - should now use actual rep
      const updatedDialogue = showDialogue(npcId, 'greeting', game);
      expect(updatedDialogue.reputationTier.name).toBe('Friendly');
      expect(updatedDialogue.text).toBe(
        '여, 친구! 다시 보니 반갑네. 배는 잘 버텨 주고 있어?'
      );
    });
  });

  describe('Error handling', () => {
    it('should throw error for unknown NPC ID in showDialogue', () => {
      expect(() => {
        showDialogue('unknown_npc', 'greeting', game);
      }).toThrow('Unknown NPC ID: unknown_npc');
    });

    it('should throw error for unknown NPC ID in selectChoice', () => {
      expect(() => {
        selectChoice('unknown_npc', 0, game);
      }).toThrow('Unknown NPC ID: unknown_npc');
    });

    it('should throw error for unknown dialogue node', () => {
      const npcId = 'chen_barnards';

      expect(() => {
        showDialogue(npcId, 'nonexistent_node', game);
      }).toThrow(
        'Unknown dialogue node: nonexistent_node for NPC: chen_barnards'
      );
    });

    it('should throw error for invalid choice index', () => {
      const npcId = 'chen_barnards';

      // Set up NPC state
      const npcState = game.getNPCState(npcId);
      npcState.rep = 0;

      // Show dialogue to establish state
      showDialogue(npcId, 'greeting', game);

      // Try to select invalid choice index
      expect(() => {
        selectChoice(npcId, 999, game);
      }).toThrow(
        'Invalid choice index: 999 for node greeting in NPC chen_barnards'
      );

      expect(() => {
        selectChoice(npcId, -1, game);
      }).toThrow(
        'Invalid choice index: -1 for node greeting in NPC chen_barnards'
      );
    });
  });

  describe('Dialogue state consistency', () => {
    it('should maintain consistent NPC information across dialogue interactions', () => {
      const npcId = 'chen_barnards';

      // Set up NPC state
      const npcState = game.getNPCState(npcId);
      npcState.rep = 25; // Warm tier

      // Show initial dialogue
      const dialogue = showDialogue(npcId, 'greeting', game);

      // Verify NPC information is correct
      expect(dialogue.npcId).toBe('chen_barnards');
      expect(dialogue.npcName).toBe('웨이 첸');
      expect(dialogue.npcRole).toBe('부두 일꾼');
      expect(dialogue.npcStation).toBe('Bore Station 7');
      expect(dialogue.reputationTier.name).toBe('Warm');

      // Select a choice that advances dialogue
      const choice = dialogue.choices.find((c) => c.next === 'small_talk');
      expect(choice).toBeDefined();

      const nextDialogue = selectChoice(npcId, choice.index, game);

      // NPC information should remain consistent
      expect(nextDialogue.npcId).toBe('chen_barnards');
      expect(nextDialogue.npcName).toBe('웨이 첸');
      expect(nextDialogue.npcRole).toBe('부두 일꾼');
      expect(nextDialogue.npcStation).toBe('Bore Station 7');
    });

    it('should handle reputation changes during dialogue correctly', () => {
      const npcId = 'chen_barnards';

      // Set up NPC state
      const npcState = game.getNPCState(npcId);
      npcState.rep = 0;

      // Show initial dialogue
      const dialogue = showDialogue(npcId, 'greeting', game);
      expect(dialogue.reputationTier.name).toBe('Neutral');

      // Select a choice that gives reputation gain
      const choice = dialogue.choices.find((c) => c.next === 'small_talk');
      const nextDialogue = selectChoice(npcId, choice.index, game);

      // Find a choice with reputation gain in the small_talk node
      const repGainChoice = nextDialogue.choices.find(
        (c) => c.repGain && c.repGain > 0
      );
      if (repGainChoice) {
        const finalDialogue = selectChoice(npcId, repGainChoice.index, game);

        // Reputation tier should be updated in the final dialogue
        const finalRep = game.getNPCState(npcId).rep;
        const expectedTier = game.getRepTier(finalRep);
        expect(finalDialogue.reputationTier.name).toBe(expectedTier.name);
      }
    });
  });
});
