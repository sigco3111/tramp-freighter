import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { OutcomePanel } from '../../src/features/danger/OutcomePanel.jsx';
import { GameProvider } from '../../src/context/GameContext.jsx';

// Mock GameCoordinator
const mockGameCoordinator = {
  getState: vi.fn(() => ({
    player: {
      karma: 0,
      factions: { authorities: 0, traders: 0, outlaws: 0, civilians: 0 },
    },
    ship: { hull: 100, engine: 100, fuel: 100, lifeSupport: 100 },
  })),
  on: vi.fn(),
  off: vi.fn(),
  emit: vi.fn(),
};

// Mock useGameEvent hook
vi.mock('../../src/hooks/useGameEvent', () => ({
  useGameEvent: vi.fn((eventName) => {
    switch (eventName) {
      case 'karmaChanged':
        return 0;
      case 'factionRepChanged':
        return { authorities: 0, traders: 0, outlaws: 0, civilians: 0 };
      default:
        return null;
    }
  }),
}));

describe('OutcomePanel', () => {
  const defaultOutcome = {
    success: true,
    encounterType: 'pirate_encounter',
    choiceMade: 'negotiate',
    explanation:
      'You successfully negotiated with the pirates and avoided combat.',
    modifiers: [
      {
        name: 'Good Karma',
        value: 0.05,
        type: 'bonus',
        description: 'Your positive karma helped in negotiations.',
      },
    ],
    consequences: {},
    karmaChanges: [
      {
        amount: 1,
        reason: 'peaceful resolution',
      },
    ],
    reputationChanges: [
      {
        faction: 'outlaws',
        amount: 5,
        reason: 'negotiated with pirates',
      },
    ],
    resourceChanges: {
      fuel: -10,
      credits: -100,
    },
  };

  const defaultProps = {
    outcome: defaultOutcome,
    onClose: vi.fn(),
    onContinue: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  const renderWithContext = (props = {}) => {
    return render(
      <GameProvider game={mockGameCoordinator}>
        <OutcomePanel {...defaultProps} {...props} />
      </GameProvider>
    );
  };

  it('should display outcome panel title', () => {
    renderWithContext();
    expect(screen.getByText('조우 결과')).toBeInTheDocument();
  });

  it('should display encounter result status', () => {
    renderWithContext();
    expect(screen.getByText('성공')).toBeInTheDocument();
    expect(screen.getByText('해적 조우')).toBeInTheDocument();
  });

  it('should display the choice made by player', () => {
    renderWithContext();
    expect(screen.getByText('당신의 선택:')).toBeInTheDocument();
    expect(screen.getByText('Negotiate')).toBeInTheDocument();
  });

  it('should display outcome explanation', () => {
    renderWithContext();
    expect(
      screen.getByText(
        'You successfully negotiated with the pirates and avoided combat.'
      )
    ).toBeInTheDocument();
  });

  it('should display modifiers that affected the result', () => {
    renderWithContext();
    expect(
      screen.getByText('결과에 영향을 준 요인')
    ).toBeInTheDocument();
    expect(screen.getByText('Good Karma')).toBeInTheDocument();
    expect(screen.getByText('+5%')).toBeInTheDocument();
  });

  it('should display karma changes', () => {
    renderWithContext();
    expect(screen.getByText('도덕적 입지')).toBeInTheDocument();
    expect(screen.getByText('카르마:')).toBeInTheDocument();
    expect(screen.getByText('+1')).toBeInTheDocument();
    expect(screen.getByText('(peaceful resolution)')).toBeInTheDocument();
  });

  it('should display reputation changes', () => {
    renderWithContext();
    expect(screen.getByText('세력 입지')).toBeInTheDocument();
    expect(screen.getAllByText('무법자:')).toHaveLength(2); // One in changes, one in current standings
    expect(screen.getByText('+5')).toBeInTheDocument();
    expect(screen.getByText('(negotiated with pirates)')).toBeInTheDocument();
  });

  it('should display resource changes', () => {
    renderWithContext();
    expect(screen.getByText('함선 및 자원')).toBeInTheDocument();
    expect(screen.getByText('연료:')).toBeInTheDocument();
    expect(screen.getByText('-10%')).toBeInTheDocument();
    expect(screen.getByText('크레딧:')).toBeInTheDocument();
    expect(screen.getByText('-₡100')).toBeInTheDocument();
  });

  it('should display current karma and faction standings', () => {
    renderWithContext();
    expect(screen.getByText('현재 카르마:')).toBeInTheDocument();
    expect(screen.getByText('현재 입지:')).toBeInTheDocument();
    expect(screen.getByText('당국:')).toBeInTheDocument();
    expect(screen.getByText('상인:')).toBeInTheDocument();
    expect(screen.getByText('민간인:')).toBeInTheDocument();
  });

  it('should handle failure outcomes', () => {
    const failureOutcome = {
      ...defaultOutcome,
      success: false,
      explanation: 'The negotiation failed and combat ensued.',
    };

    renderWithContext({ outcome: failureOutcome });
    expect(screen.getByText('실패')).toBeInTheDocument();
    expect(
      screen.getByText('The negotiation failed and combat ensued.')
    ).toBeInTheDocument();
  });

  it('should call onContinue when continue button is clicked', () => {
    const onContinue = vi.fn();
    renderWithContext({ onContinue });

    const continueButton = screen.getByText('계속');
    fireEvent.click(continueButton);

    expect(onContinue).toHaveBeenCalledTimes(1);
  });

  it('should call onClose when close button is clicked', () => {
    const onClose = vi.fn();
    renderWithContext({ onClose });

    const closeButton = screen.getByText('×');
    fireEvent.click(closeButton);

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('should handle empty outcome gracefully', () => {
    renderWithContext({ outcome: null });
    // Component should not render anything when outcome is null
    expect(screen.queryByText('Encounter Outcome')).not.toBeInTheDocument();
  });

  it('should display additional effects when present', () => {
    const outcomeWithEffects = {
      ...defaultOutcome,
      consequences: {
        additionalEffects: [
          "Your ship's reputation precedes you in this sector.",
          'Pirates in this area will be more cautious around you.',
        ],
      },
    };

    renderWithContext({ outcome: outcomeWithEffects });
    expect(screen.getByText('추가 효과')).toBeInTheDocument();
    expect(
      screen.getByText("Your ship's reputation precedes you in this sector.")
    ).toBeInTheDocument();
    expect(
      screen.getByText('Pirates in this area will be more cautious around you.')
    ).toBeInTheDocument();
  });

  it('should hide Consequences section when no resource, karma, reputation, or additional effects', () => {
    const emptyConsequencesOutcome = {
      ...defaultOutcome,
      consequences: {},
      karmaChanges: [],
      reputationChanges: [],
      resourceChanges: {},
    };

    renderWithContext({ outcome: emptyConsequencesOutcome });
    expect(screen.queryByText('Consequences')).not.toBeInTheDocument();
  });

  it('should format different resource types correctly', () => {
    const outcomeWithVariousResources = {
      ...defaultOutcome,
      resourceChanges: {
        hull: -20,
        engine: -5,
        fuel: -15,
        lifeSupport: -10,
        credits: 500,
        cargo: -2,
        days: 3,
      },
    };

    renderWithContext({ outcome: outcomeWithVariousResources });
    expect(screen.getByText('선체 무결성:')).toBeInTheDocument();
    expect(screen.getByText('엔진 상태:')).toBeInTheDocument();
    expect(screen.getByText('생명 유지:')).toBeInTheDocument();
    expect(screen.getByText('+₡500')).toBeInTheDocument();
    expect(screen.getByText('-2% 화물')).toBeInTheDocument();
    expect(screen.getByText('+3일')).toBeInTheDocument();
  });
});
