import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { render, cleanup, waitFor } from '@testing-library/react';
import * as fc from 'fast-check';
import { ShipStatusPanel } from '../../src/features/ship-status/ShipStatusPanel.jsx';
import { GameCoordinator } from '@game/state/game-coordinator.js';
import { STAR_DATA } from '../../src/game/data/star-data.js';
import { WORMHOLE_DATA } from '../../src/game/data/wormhole-data.js';
import { SHIP_CONFIG } from '../../src/game/constants.js';
import { sanitizeShipName } from '../../src/game/utils/string-utils.js';
import { createWrapper } from '../react-test-utils.jsx';

/**
 * Property tests for ShipStatusPanel component
 *
 * Validates that the ship status panel correctly displays ship information
 * and updates reactively when ship data changes.
 *
 * React Migration Spec: Requirements 8.7
 */
describe('ShipStatusPanel Property Tests', () => {
  // Suppress React act() warnings for property tests
  beforeEach(() => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should render as a React component with all sections', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        const wrapper = createWrapper(game);

        // Render ShipStatusPanel
        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        // Verify the component renders
        const panel = container.querySelector('#ship-status-panel');
        expect(panel).toBeTruthy();
        expect(panel.classList.contains('ship-status-panel')).toBe(true);
        expect(panel.classList.contains('visible')).toBe(true);

        // Verify all main sections exist
        expect(panel.querySelector('h2')).toBeTruthy();
        expect(panel.querySelector('.close-btn')).toBeTruthy();

        // Verify condition section
        const conditionSection = Array.from(
          panel.querySelectorAll('.ship-status-section')
        ).find((section) => section.textContent.includes('상태'));
        expect(conditionSection).toBeTruthy();

        // Verify upgrades section
        const upgradesSection = Array.from(
          panel.querySelectorAll('.ship-status-section')
        ).find((section) => section.textContent.includes('업그레이드'));
        expect(upgradesSection).toBeTruthy();

        // Verify quirks section
        const quirksSection = Array.from(
          panel.querySelectorAll('.ship-status-section')
        ).find((section) => section.textContent.includes('함선 특성'));
        expect(quirksSection).toBeTruthy();
      }),
      { numRuns: 100 }
    );
  });

  it('should display ship name in header', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        const shipName = game.getShip().name;
        const wrapper = createWrapper(game);

        // Render ShipStatusPanel
        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        // Verify ship name is displayed in header
        const header = container.querySelector('h2');
        expect(header.textContent).toContain(shipName);
        expect(header.textContent).toContain('함선 상태');
      }),
      { numRuns: 100 }
    );
  });

  it('should display all three condition bars', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        const wrapper = createWrapper(game);

        // Render ShipStatusPanel
        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        // Verify all three condition bars are present
        const conditionItems = container.querySelectorAll(
          '.ship-status-condition-item'
        );
        expect(conditionItems.length).toBe(3);

        // Verify each condition has a label and bar
        conditionItems.forEach((item) => {
          expect(item.querySelector('.info-label')).toBeTruthy();
          expect(item.querySelector('.condition-bar')).toBeTruthy();
          expect(item.querySelector('.condition-fill')).toBeTruthy();
          expect(item.querySelector('.condition-value')).toBeTruthy();
        });

        // Verify condition labels
        const labels = Array.from(
          container.querySelectorAll('.ship-status-condition-item .info-label')
        ).map((el) => el.textContent);
        expect(labels).toContain('선체');
        expect(labels).toContain('엔진');
        expect(labels).toContain('생명 유지');
      }),
      { numRuns: 100 }
    );
  });

  it('should display ship quirks with all details', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        const ship = game.getShip();
        const wrapper = createWrapper(game);

        // Render ShipStatusPanel
        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        // Find quirks section
        const quirksSection = Array.from(
          container.querySelectorAll('.ship-status-section')
        ).find((section) => section.textContent.includes('함선 특성'));

        if (ship.quirks.length === 0) {
          // Should show empty message
          expect(quirksSection.textContent).toContain('특성 없음');
        } else {
          // Should display each quirk
          const quirkItems = quirksSection.querySelectorAll('.quirk-item');
          expect(quirkItems.length).toBe(ship.quirks.length);

          // Verify each quirk has all required elements
          quirkItems.forEach((item, index) => {
            const quirkId = ship.quirks[index];
            const quirkDef = SHIP_CONFIG.QUIRKS[quirkId];

            expect(item.querySelector('.quirk-header')).toBeTruthy();
            expect(item.querySelector('.quirk-icon')).toBeTruthy();
            expect(item.querySelector('.quirk-name')).toBeTruthy();
            expect(item.querySelector('.quirk-description')).toBeTruthy();
            expect(item.querySelector('.quirk-flavor')).toBeTruthy();

            // Verify quirk name is displayed
            expect(item.textContent).toContain(quirkDef.name);
            expect(item.textContent).toContain(quirkDef.description);
            expect(item.textContent).toContain(quirkDef.flavor);
          });
        }
      }),
      { numRuns: 100 }
    );
  });

  it('should display upgrades or empty message', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        const ship = game.getShip();
        const wrapper = createWrapper(game);

        // Render ShipStatusPanel
        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        // Find upgrades section
        const upgradesSection = Array.from(
          container.querySelectorAll('.ship-status-section')
        ).find((section) => section.textContent.includes('업그레이드'));

        if (ship.upgrades.length === 0) {
          // Should show empty message
          expect(upgradesSection.textContent).toContain(
            '설치된 업그레이드 없음'
          );
        } else {
          // Should display each upgrade
          const upgradeItems = upgradesSection.querySelectorAll('.quirk-item');
          expect(upgradeItems.length).toBe(ship.upgrades.length);

          // Verify each upgrade has required elements
          upgradeItems.forEach((item, index) => {
            const upgradeId = ship.upgrades[index];
            const upgradeDef = SHIP_CONFIG.UPGRADES[upgradeId];

            expect(item.querySelector('.quirk-header')).toBeTruthy();
            expect(item.querySelector('.quirk-icon')).toBeTruthy();
            expect(item.querySelector('.quirk-name')).toBeTruthy();
            expect(item.querySelector('.quirk-description')).toBeTruthy();

            // Verify upgrade name is displayed
            expect(item.textContent).toContain(upgradeDef.name);
            expect(item.textContent).toContain(upgradeDef.description);
          });
        }
      }),
      { numRuns: 100 }
    );
  });

  it('should update ship name when shipNameChanged event fires', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc
          .string({ minLength: 3, maxLength: 20 })
          .filter((s) => sanitizeShipName(s) !== SHIP_CONFIG.DEFAULT_NAME),
        async (newName) => {
          cleanup();

          const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
          game.initNewGame();

          const wrapper = createWrapper(game);

          // Render ShipStatusPanel
          const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
            wrapper,
          });

          // Get initial ship name
          const initialHeader = container.querySelector('h2');
          const initialName = game.getShip().name;
          expect(initialHeader.textContent).toContain(initialName);

          // Update ship name
          game.updateShipName(newName);

          // Wait for component to re-render
          await waitFor(() => {
            const header = container.querySelector('h2');
            const sanitizedName = game.getShip().name;
            expect(header.textContent).toContain(sanitizedName);
            expect(header.textContent).not.toContain(initialName);
          });
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should update condition bars when shipConditionChanged event fires', async () => {
    await fc.assert(
      fc.asyncProperty(
        fc.integer({ min: 0, max: 100 }),
        fc.integer({ min: 0, max: 100 }),
        fc.integer({ min: 0, max: 100 }),
        async (newHull, newEngine, newLifeSupport) => {
          cleanup();

          const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
          game.initNewGame();

          const wrapper = createWrapper(game);

          // Render ShipStatusPanel
          const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
            wrapper,
          });

          // Update ship condition
          game.state.ship.hull = newHull;
          game.state.ship.engine = newEngine;
          game.state.ship.lifeSupport = newLifeSupport;

          game.emit('shipConditionChanged', {
            hull: newHull,
            engine: newEngine,
            lifeSupport: newLifeSupport,
          });

          // Wait for component to re-render
          await waitFor(() => {
            const conditionValues = Array.from(
              container.querySelectorAll('.condition-value')
            ).map((el) => parseInt(el.textContent));

            expect(conditionValues).toContain(newHull);
            expect(conditionValues).toContain(newEngine);
            expect(conditionValues).toContain(newLifeSupport);
          });
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply per-system color classes matching the HUD', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        const wrapper = createWrapper(game);

        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        const conditionBars = container.querySelectorAll('.condition-bar');
        expect(conditionBars.length).toBe(3);

        // Bars use per-system classes matching HUD colors
        expect(conditionBars[0].classList.contains('hull')).toBe(true);
        expect(conditionBars[1].classList.contains('engine')).toBe(true);
        expect(conditionBars[2].classList.contains('life-support')).toBe(true);
      }),
      { numRuns: 100 }
    );
  });

  it('should handle missing quirk definitions gracefully', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        // Add an invalid quirk ID
        game.state.ship.quirks.push('invalid_quirk_id');

        const wrapper = createWrapper(game);

        // Should render without errors
        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        // Panel should still render
        expect(container.querySelector('#ship-status-panel')).toBeTruthy();

        // Should only render valid quirks
        const quirksSection = Array.from(
          container.querySelectorAll('.ship-status-section')
        ).find((section) => section.textContent.includes('함선 특성'));

        const quirkItems = quirksSection.querySelectorAll('.quirk-item');
        // Should have one less item than total quirks (invalid one filtered out)
        expect(quirkItems.length).toBe(game.state.ship.quirks.length - 1);
      }),
      { numRuns: 100 }
    );
  });

  it('should handle missing upgrade definitions gracefully', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        // Add an invalid upgrade ID
        game.state.ship.upgrades.push('invalid_upgrade_id');

        const wrapper = createWrapper(game);

        // Should render without errors
        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        // Panel should still render
        expect(container.querySelector('#ship-status-panel')).toBeTruthy();

        // Should only render valid upgrades
        const upgradesSection = Array.from(
          container.querySelectorAll('.ship-status-section')
        ).find((section) => section.textContent.includes('업그레이드'));

        const upgradeItems = upgradesSection.querySelectorAll('.quirk-item');
        // Should have one less item than total upgrades (invalid one filtered out)
        expect(upgradeItems.length).toBe(game.state.ship.upgrades.length - 1);
      }),
      { numRuns: 100 }
    );
  });

  it('should subscribe to upgradesChanged event', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        const wrapper = createWrapper(game);

        // Render ShipStatusPanel
        const { container } = render(<ShipStatusPanel onClose={() => {}} />, {
          wrapper,
        });

        // Verify initial state - no upgrades
        let upgradesSection = Array.from(
          container.querySelectorAll('.ship-status-section')
        ).find((section) => section.textContent.includes('업그레이드'));
        expect(upgradesSection.textContent).toContain('설치된 업그레이드 없음');

        // Verify component subscribed to upgradesChanged event
        const subscriberCount = game.subscribers.upgradesChanged.length;
        expect(subscriberCount).toBeGreaterThan(0);
      }),
      { numRuns: 100 }
    );
  });
});
