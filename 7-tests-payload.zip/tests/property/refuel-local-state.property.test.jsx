import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { render, screen, fireEvent, cleanup } from '@testing-library/react';
import * as fc from 'fast-check';
import { RefuelPanel } from '../../src/features/refuel/RefuelPanel.jsx';
import { GameCoordinator } from '@game/state/game-coordinator.js';
import { STAR_DATA } from '../../src/game/data/star-data.js';
import { WORMHOLE_DATA } from '../../src/game/data/wormhole-data.js';
import { createWrapper } from '../react-test-utils.jsx';

/**
 * Property 25: Refuel panel manages local state
 *
 * Validates that the RefuelPanel component manages slider value in local React state
 * and only updates game state when the refuel action is confirmed.
 *
 * React Migration Spec: Requirements 27.1, 27.2
 */
describe('Property 25: Refuel panel manages local state', () => {
  // Suppress React act() warnings for property tests
  beforeEach(() => {
    vi.spyOn(console, 'error').mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should maintain slider value in local state without affecting game state', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 10, max: 50 }), // Random slider value
        (sliderValue) => {
          cleanup();

          const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
          game.initNewGame();

          // Set up initial state
          game.state.player.credits = 10000;
          game.state.ship.fuel = 50;
          game.state.player.currentSystem = 0; // Sol

          const initialFuel = game.state.ship.fuel;
          const initialCredits = game.state.player.credits;

          const wrapper = createWrapper(game);

          // Render RefuelPanel
          const { container } = render(<RefuelPanel onClose={() => {}} />, {
            wrapper,
          });

          // Find the slider
          const slider = container.querySelector('#refuel-amount');
          expect(slider).toBeTruthy();

          // Change slider value
          fireEvent.change(slider, { target: { value: sliderValue } });

          // Verify slider value changed in UI
          expect(Number(slider.value)).toBe(sliderValue);

          // Verify game state has NOT changed (local state only)
          expect(game.state.ship.fuel).toBe(initialFuel);
          expect(game.state.player.credits).toBe(initialCredits);

          return true;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should update game state only when confirm button is clicked', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 5, max: 20 }), // Random refuel amount
        (refuelAmount) => {
          cleanup();

          const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
          game.initNewGame();

          // Set up initial state with enough credits
          game.state.player.credits = 10000;
          game.state.ship.fuel = 50;
          game.state.player.currentSystem = 0; // Sol

          const initialFuel = game.state.ship.fuel;
          const fuelPrice = game.getFuelPrice(0);
          const expectedCost = refuelAmount * fuelPrice;

          const wrapper = createWrapper(game);

          // Render RefuelPanel
          const { container } = render(<RefuelPanel onClose={() => {}} />, {
            wrapper,
          });

          // Find the slider and set value
          const slider = container.querySelector('#refuel-amount');
          fireEvent.change(slider, { target: { value: refuelAmount } });

          // Game state should not have changed yet
          expect(game.state.ship.fuel).toBe(initialFuel);

          // Click confirm button
          const confirmButton = screen.getByText('주유 확인');
          fireEvent.click(confirmButton);

          // Now game state should be updated
          expect(game.state.ship.fuel).toBeCloseTo(
            initialFuel + refuelAmount,
            1
          );
          expect(game.state.player.credits).toBeLessThan(10000);
          expect(game.state.player.credits).toBeCloseTo(
            10000 - expectedCost,
            1
          );

          return true;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should reset local state after successful refuel', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 5, max: 20 }), // Random refuel amount
        (refuelAmount) => {
          cleanup();

          const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
          game.initNewGame();

          // Set up initial state
          game.state.player.credits = 10000;
          game.state.ship.fuel = 50;
          game.state.player.currentSystem = 0; // Sol

          const wrapper = createWrapper(game);

          // Render RefuelPanel
          const { container } = render(<RefuelPanel onClose={() => {}} />, {
            wrapper,
          });

          // Set slider value
          const slider = container.querySelector('#refuel-amount');
          fireEvent.change(slider, { target: { value: refuelAmount } });

          // Verify slider has the value
          expect(Number(slider.value)).toBe(refuelAmount);

          // Click confirm button
          const confirmButton = screen.getByText('주유 확인');
          fireEvent.click(confirmButton);

          // Slider should be reset to 0 after successful refuel
          expect(Number(slider.value)).toBe(0);

          return true;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should display real-time cost calculation based on local state', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 1, max: 30 }), // Random slider value
        (sliderValue) => {
          cleanup();

          const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
          game.initNewGame();

          // Set up initial state
          game.state.player.credits = 10000;
          game.state.ship.fuel = 50;
          game.state.player.currentSystem = 0; // Sol

          const fuelPrice = game.getFuelPrice(0);
          const expectedCost = sliderValue * fuelPrice;

          const wrapper = createWrapper(game);

          // Render RefuelPanel
          const { container } = render(<RefuelPanel onClose={() => {}} />, {
            wrapper,
          });

          // Change slider value
          const slider = container.querySelector('#refuel-amount');
          fireEvent.change(slider, { target: { value: sliderValue } });

          // Verify cost display updates
          const costDisplay = container.querySelector('.cost-value');
          expect(costDisplay).toBeTruthy();
          expect(costDisplay.textContent).toContain(expectedCost.toString());

          return true;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should display validation messages based on local state', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        // Set up state with fuel at 100% (can't refuel more)
        game.state.player.credits = 10000;
        game.state.ship.fuel = 100;
        game.state.player.currentSystem = 0; // Sol

        const wrapper = createWrapper(game);

        // Render RefuelPanel
        const { container } = render(<RefuelPanel onClose={() => {}} />, {
          wrapper,
        });

        // Slider should be at 0 because fuel is already full
        const slider = container.querySelector('#refuel-amount');
        expect(Number(slider.max)).toBe(0);
        expect(Number(slider.value)).toBe(0);

        // Should display info message about entering an amount
        const validationMessage = container.querySelector(
          '.validation-message.info'
        );
        expect(validationMessage).toBeTruthy();
        expect(validationMessage.textContent).toContain('주유할 양을 입력하세요');

        return true;
      }),
      { numRuns: 100 }
    );
  });

  it('should not update game state when validation fails', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        game.initNewGame();

        // Set up state with fuel at 100% (can't refuel)
        game.state.player.credits = 10000;
        game.state.ship.fuel = 100;
        game.state.player.currentSystem = 0; // Sol

        const initialFuel = game.state.ship.fuel;
        const initialCredits = game.state.player.credits;

        const wrapper = createWrapper(game);

        // Render RefuelPanel
        render(<RefuelPanel onClose={() => {}} />, {
          wrapper,
        });

        // Confirm button should be disabled (amount is 0)
        const confirmButton = screen.getByText('주유 확인');
        expect(confirmButton.disabled).toBe(true);

        // Try to click (should not work because button is disabled)
        fireEvent.click(confirmButton);

        // Game state should not have changed
        expect(game.state.ship.fuel).toBe(initialFuel);
        expect(game.state.player.credits).toBe(initialCredits);

        return true;
      }),
      { numRuns: 100 }
    );
  });
});
