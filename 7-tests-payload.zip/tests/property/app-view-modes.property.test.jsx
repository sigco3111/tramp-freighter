import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { render, screen, cleanup, fireEvent } from '@testing-library/react';
import * as fc from 'fast-check';
import App from '../../src/App.jsx';
import { GameCoordinator } from '@game/state/game-coordinator.js';
import { STAR_DATA } from '../../src/game/data/star-data.js';
import { WORMHOLE_DATA } from '../../src/game/data/wormhole-data.js';
import { createWrapper } from '../react-test-utils.jsx';

// Mock the scene module to avoid WebGL errors in jsdom
vi.mock('../../src/game/engine/scene', () => {
  const mockRenderer = {
    domElement: document.createElement('canvas'),
    setSize: vi.fn(),
    setPixelRatio: vi.fn(),
    render: vi.fn(),
    dispose: vi.fn(),
  };

  const mockControls = {
    update: vi.fn(),
  };

  const mockScene = {
    background: null,
    fog: null,
    add: vi.fn(),
    traverse: vi.fn(),
  };

  const mockCamera = {
    aspect: 1,
    position: { set: vi.fn() },
    lookAt: vi.fn(),
    updateProjectionMatrix: vi.fn(),
  };

  const mockLights = {
    ambientLight: {},
    directionalLight: {
      position: { set: vi.fn().mockReturnThis(), normalize: vi.fn() },
    },
  };

  // Mock stars array with minimal data needed for updateCurrentSystemIndicator
  const mockStars = [
    {
      data: { id: 1 },
      position: { x: 0, y: 0, z: 0 },
      sprite: { material: { color: { setHex: vi.fn() } } },
      originalColor: 0xffffff,
    },
  ];

  return {
    initScene: vi.fn(() => ({
      scene: mockScene,
      camera: mockCamera,
      renderer: mockRenderer,
      controls: mockControls,
      lights: mockLights,
      stars: mockStars,
      sectorBoundary: { visible: true },
    })),
    onWindowResize: vi.fn(),
    zoomIn: vi.fn(),
    zoomOut: vi.fn(),
    toggleBoundary: vi.fn(() => true),
  };
});

// Mock the animation system
vi.mock('../../src/game/engine/game-animation', () => {
  return {
    JumpAnimationSystem: vi.fn().mockImplementation(() => ({
      isAnimating: false,
      inputLockManager: {
        isInputLocked: vi.fn(() => false),
        lock: vi.fn(),
        unlock: vi.fn(),
      },
      playJumpAnimation: vi.fn(),
    })),
  };
});

// Suppress console warnings during tests
beforeEach(() => {
  vi.spyOn(console, 'error').mockImplementation(() => {});
  vi.spyOn(console, 'warn').mockImplementation(() => {});
});

afterEach(() => {
  vi.restoreAllMocks();
});

/**
 * React Migration Spec, Property 26: ORBIT mode displays starmap and HUD
 * Validates: Requirements 9.2, 25.1, 25.2
 *
 * For any view mode set to ORBIT, only the starmap and HUD should be displayed.
 * Station menu and panels should not be visible.
 */
describe('Property: ORBIT mode displays starmap and HUD', () => {
  it('should display starmap and HUD in ORBIT mode', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        // Clear localStorage to ensure no saved game exists
        localStorage.clear();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        // Don't initialize game - let App handle it

        const wrapper = createWrapper(game);

        // Render App component
        const { container } = render(<App />, { wrapper });

        // Start a new game from title screen
        const newGameButton = screen.getByText('새 게임');
        fireEvent.click(newGameButton);

        // Submit ship name (uses default if empty)
        const confirmButton = screen.getByText('확인');
        fireEvent.click(confirmButton);

        // Dismiss the auto-shown instructions modal
        const closeModal = screen.getByLabelText('창 닫기');
        fireEvent.click(closeModal);

        // Now we should be in ORBIT mode
        // Verify starmap container is present (StarMapCanvas component)
        const starmapContainer = container.querySelector('.starmap-container');
        expect(starmapContainer).toBeTruthy();

        // Verify HUD is present
        const hud = container.querySelector('#game-hud');
        expect(hud).toBeTruthy();

        // Verify station menu is NOT present (initial state is ORBIT)
        const stationMenu = container.querySelector('#station-interface');
        expect(stationMenu).toBeFalsy();

        // Verify panel container is NOT present
        const panelContainer = container.querySelector('.panel-container');
        expect(panelContainer).toBeFalsy();

        return starmapContainer && hud && !stationMenu && !panelContainer;
      }),
      { numRuns: 100 }
    );
  });
});

/**
 * React Migration Spec, Property 27: STATION mode displays station menu
 * Validates: Requirements 9.3, 25.3
 *
 * For any view mode set to STATION, the station menu should be displayed.
 */
describe('Property: STATION mode displays station menu', () => {
  it('should display station menu when docked', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        // Clear localStorage to ensure no saved game exists
        localStorage.clear();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        // Don't initialize game - let App handle it

        const wrapper = createWrapper(game);

        // Render App component
        const { container } = render(<App />, { wrapper });

        // Start a new game from title screen
        const newGameButton = screen.getByText('새 게임');
        fireEvent.click(newGameButton);

        // Submit ship name (uses default if empty)
        const confirmButton = screen.getByText('확인');
        fireEvent.click(confirmButton);

        // Dismiss the auto-shown instructions modal
        const closeModal = screen.getByLabelText('창 닫기');
        fireEvent.click(closeModal);

        // Click dock button to transition to STATION mode
        const dockButton = screen.getByText('도킹');
        fireEvent.click(dockButton);

        // Verify station menu is now present
        const stationMenu = container.querySelector('#station-interface');
        expect(stationMenu).toBeTruthy();

        // Verify starmap and HUD are still present (they're always visible)
        const starmapContainer = container.querySelector('.starmap-container');
        expect(starmapContainer).toBeTruthy();

        const hud = container.querySelector('#game-hud');
        expect(hud).toBeTruthy();

        // Verify panel container is NOT present
        const panelContainer = container.querySelector('.panel-container');
        expect(panelContainer).toBeFalsy();

        return true;
      }),
      { numRuns: 100 }
    );
  });
});

/**
 * React Migration Spec, Property 28: Active panel displays alongside station menu
 * Validates: Requirements 9.4, 25.4
 *
 * When a panel is opened from the station menu, both the station menu and
 * the panel are visible simultaneously (flattened view state).
 */
describe('Property: Active panel displays alongside station menu', () => {
  it('should display active panel alongside station menu when opened', () => {
    fc.assert(
      fc.property(fc.constant(null), () => {
        cleanup();

        // Clear localStorage to ensure no saved game exists
        localStorage.clear();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        // Don't initialize game - let App handle it

        const wrapper = createWrapper(game);

        // Render App component
        const { container } = render(<App />, { wrapper });

        // Start a new game from title screen
        const newGameButton = screen.getByText('새 게임');
        fireEvent.click(newGameButton);

        // Submit ship name (uses default if empty)
        const confirmButton = screen.getByText('확인');
        fireEvent.click(confirmButton);

        // Dismiss the auto-shown instructions modal
        const closeModal = screen.getByLabelText('창 닫기');
        fireEvent.click(closeModal);

        // Click dock button to transition to STATION mode
        const dockButton = screen.getByText('도킹');
        fireEvent.click(dockButton);

        // Click open panel button
        const openPanelButton = screen.getByText('거래');
        fireEvent.click(openPanelButton);

        // Verify panel container is now present
        const panelContainer = container.querySelector('.panel-container');
        expect(panelContainer).toBeTruthy();

        // Verify panel displays the trade panel (check for trade-specific content)
        expect(panelContainer.textContent).toContain('거래 -');

        // Verify starmap and HUD are still present
        const starmapContainer = container.querySelector('.starmap-container');
        expect(starmapContainer).toBeTruthy();

        const hud = container.querySelector('#game-hud');
        expect(hud).toBeTruthy();

        // Station menu stays visible alongside panel (flattened state)
        const stationMenu = container.querySelector('#station-interface');
        expect(stationMenu).toBeTruthy();

        return true;
      }),
      { numRuns: 100 }
    );
  });
});

/**
 * React Migration Spec, Property 29: View mode changes update visibility
 * Validates: Requirements 9.5
 *
 * For any view mode change, the visible components should update to match
 * the new view mode.
 */
describe('Property: View mode changes update visibility', () => {
  it('should update visibility when transitioning between view modes', () => {
    fc.assert(
      fc.property(fc.constant('transition'), () => {
        cleanup();

        // Clear localStorage to ensure no saved game exists
        localStorage.clear();

        const game = new GameCoordinator(STAR_DATA, WORMHOLE_DATA);
        // Don't initialize game - let App handle it

        const wrapper = createWrapper(game);

        // Render App component
        const { container } = render(<App />, { wrapper });

        // Start a new game from title screen
        const newGameButton = screen.getByText('새 게임');
        fireEvent.click(newGameButton);

        // Submit ship name (uses default if empty)
        const confirmButton = screen.getByText('확인');
        fireEvent.click(confirmButton);

        // Dismiss the auto-shown instructions modal
        const closeModal = screen.getByLabelText('창 닫기');
        fireEvent.click(closeModal);

        // Initial state: ORBIT mode
        let stationMenu = container.querySelector('#station-interface');
        let panelContainer = container.querySelector('.panel-container');
        expect(stationMenu).toBeFalsy();
        expect(panelContainer).toBeFalsy();

        // Transition to STATION mode
        const dockButton = screen.getByText('도킹');
        fireEvent.click(dockButton);

        stationMenu = container.querySelector('#station-interface');
        panelContainer = container.querySelector('.panel-container');
        expect(stationMenu).toBeTruthy();
        expect(panelContainer).toBeFalsy();

        // Open a panel — station menu stays visible alongside it
        const openPanelButton = screen.getByText('거래');
        fireEvent.click(openPanelButton);

        stationMenu = container.querySelector('#station-interface');
        panelContainer = container.querySelector('.panel-container');
        expect(stationMenu).toBeTruthy();
        expect(panelContainer).toBeTruthy();

        // Close the panel — station menu stays, panel goes away
        const closePanelButtons = screen.getAllByText('×');
        // Find the close button in the panel container (not the station menu)
        const closePanelButton = closePanelButtons.find((btn) =>
          btn.closest('.panel-container')
        );
        fireEvent.click(closePanelButton);

        stationMenu = container.querySelector('#station-interface');
        panelContainer = container.querySelector('.panel-container');
        expect(stationMenu).toBeTruthy();
        expect(panelContainer).toBeFalsy();

        // Transition back to ORBIT mode via close button
        const stationCloseBtn = container.querySelector(
          '#station-interface .close-btn'
        );
        fireEvent.click(stationCloseBtn);

        stationMenu = container.querySelector('#station-interface');
        panelContainer = container.querySelector('.panel-container');
        expect(stationMenu).toBeFalsy();
        expect(panelContainer).toBeFalsy();

        return true;
      }),
      { numRuns: 100 }
    );
  });
});
